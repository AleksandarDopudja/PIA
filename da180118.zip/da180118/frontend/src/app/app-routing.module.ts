import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddworkshopComponent } from './addworkshop/addworkshop.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminworkshopsComponent } from './adminworkshops/adminworkshops.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { LoginComponent } from './login/login.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { OrganizerComponent } from './organizer/organizer.component';
import { OrganizerprofileComponent } from './organizerprofile/organizerprofile.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationComponent } from './registration/registration.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { UserpageComponent } from './userpage/userpage.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { WorkshopdetailsComponent } from './workshopdetails/workshopdetails.component';
import { WorkshoporganizerComponent } from './workshoporganizer/workshoporganizer.component';
import { WorkshopproposalComponent } from './workshopproposal/workshopproposal.component';

const routes: Routes = [
  {path: '', component: WelcomepageComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegistrationComponent},
  {path: 'userpage', component: UserpageComponent},
  {path:'workshopdetails', component: WorkshopdetailsComponent},
  {path:'profile', component: ProfileComponent},
  {path:'workshopproposal', component: WorkshopproposalComponent},
  {path: 'organizer', component: OrganizerComponent},
  {path:'organizerprofile', component: OrganizerprofileComponent},
  {path:'addworkshop', component: AddworkshopComponent},
  {path:'workshoporganizer', component: WorkshoporganizerComponent},
  {path:'changepassword', component: ChangepasswordComponent},
  {path:'loginadmin', component: LoginadminComponent},
  {path:'adminpage', component: AdminpageComponent},
  {path:'userdetails', component: UserdetailsComponent},
  {path:'adminworkshops', component: AdminworkshopsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
