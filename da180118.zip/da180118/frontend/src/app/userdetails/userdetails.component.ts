import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  user: User;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage.getItem('userdetails'));
    if(this.user == null){
      this.user = new User()
      this.new = true;
    }
    else{
    this.firstname = this.user.firstname;
    this.lastname = this.user.lastname;
    this.username = this.user.username;
    this.password = this.user.password;
    this.mail = this.user.mail;
    this.type = this.user.type;
    if(this.type == 2){
      this.myCheckbox = true;
    }
    this.orgname = this.user.orgname;
    this.orgadr = this.user.orgadr;
    this.orgmatnum = this.user.orgmatnum;
    this.foto= this.user.foto;
    this.tell = this.user.tell;
    this.status = this.user.status;
    }
  }

  new:boolean = false;

  firstname: string = "";
  lastname: string = "";
  username: string = "";
  password: string = "";
  mail: string = "";
  type: number = 0;
  orgname: string = "";
  orgadr: string = "";
  orgmatnum: string = "";
  foto: any;
  tell: string = "";
  status: number = 0;
  message: string = "";
  myCheckbox: boolean;


  changeUser(){
    this.message = "";

    if(this.myCheckbox==false){

    }

    this.service.doesUserExist(this.username).subscribe((val:boolean)=>{
      //alert(val);
      if(val==true && this.user.username != this.username){
        this.message = "Korisnocko ime vec u upotrebi!"
      }else{

        this.service.doesMailInUse(this.mail).subscribe((val2:boolean)=>{

          if(val2==true && this.user.mail != this.mail){
            this.message = "Mail vec u upotrebi!!"
          }else{
            alert(this.user._id);
            this.service.changeUserDetails(this.user._id, this.firstname, this.lastname, this.username, this.password, this.mail, this.type, this.orgname, this.orgadr, this.orgmatnum, this.foto, this.tell, this.status).subscribe((resp)=>{
              let user = new User();
              user.firstname = this.firstname;
              user.lastname = this.lastname;
              user.username = this.username;
              user.password = this.password;
              user.mail = this.mail;
              user.type = this.type;
              user.orgname = this.orgname;
              user.orgadr  =this.orgadr;
              user.orgmatnum = this.orgmatnum;
              user.foto = this.foto;
              user.tell = this.tell;
              user.status = this.status;
        
              sessionStorage.setItem('userdetails', JSON.stringify(user));
              this.ngOnInit();
            })
            
          }
        })
      }
    })

    return true;
  }

  deleteUser() {
    
    this.service.deleteUser(this.user.username).subscribe(resp=>{
      alert("korisnik obrisan")
      this.router.navigate(['../adminpage']);
    })
  }

  url: any; //Angular 11, for stricter type
	msg = "";
	
	//selectFile(event) { //Angular 8
	selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'Izaberite sliku!';
			return;
		}

    var name = event.target.files[0].name;
    var type = event.target.files[0].type;
    var size = event.target.files[0].size;
    var modifiedDate = event.target.files[0].lastModifiedDate;

    let format = type.split("/");
    //console.log(format[1])

    if(format[1]!='png' && format[1]!='jpg'){
      this.msg = 'Los format!(samo JPG/PNG)';
			return;
    }
		
		var mimeType = event.target.files[0].type;
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Samo su podrzane slike!";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {

			this.msg = "";
			this.url = reader.result; 

      this.foto = this.url;
      console.log(this.url.width);
		}
	}

  register(){

    this.type=1;
    if(this.myCheckbox){
      this.type = 2;
    }
   
    this.status = 1;
    //let format = Image.value.split(".");
    //let slika = Image.value.split("\\");
    

    
    this.service.doesUserExist(this.username).subscribe((val:boolean)=>{
      //alert(val);
      if(val==true){
        this.message = "Korisnocko ime vec u upotrebi!"
        return false;
      }else{

        this.service.doesMailInUse(this.mail).subscribe((val2:boolean)=>{

          if(val2==true){
            this.message = "Mail vec u upotrebi!!"
            return false;
          }else{
            this.service.register(this.firstname, this.lastname, this.username, this.password,this.tell,this.mail, this.type,this.orgname, this.orgadr, this.orgmatnum, this.url, this.status).subscribe((resp)=>{
            
              if(resp['message']=='user added'){
                alert("Uspesna registracija!");
                this.router.navigate(['../adminpage']);
                return true;
              }else{
                alert("error");
                return false;
              }
            });
            return false;
          }
        })

        return false;
      }
    })

    return false;
  }


}
