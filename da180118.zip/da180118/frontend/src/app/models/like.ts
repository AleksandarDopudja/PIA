export class Like{
    username: string;
    name: string;
    time: Date;
    _id: string;
}