export class Message{
    name: string;
    time: Date;
    txt: string;
}