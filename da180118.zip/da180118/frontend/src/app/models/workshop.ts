import { ArrayType } from "@angular/compiler";

export class Workshop{
    mainphoto: string;
    name: string;
    date: Date;
    place: string;
    shortinfo: string;
    info: string;
    galery: Array<String>;
    org: string;
    capacity: number;
    status: string;
    _id: string;
}