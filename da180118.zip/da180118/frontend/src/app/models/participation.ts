export class Participation{
    name: string;
    username: string; 
    date: string; 
    org: string;
    foto: string;
    place: string;
    shortinfo: string;
}