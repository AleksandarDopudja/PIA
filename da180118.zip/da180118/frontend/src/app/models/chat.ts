import { Message } from "./message";

export class Chat{
    _id: string;
    orgusername: string;
    username: string;
    workshopname: string;
    messages: Array<Message>;
}