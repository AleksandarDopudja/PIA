import { Chat } from "./chat";
import { Message } from "./message";

export class User{
    firstname: string;
    lastname: string;
    username: string;
    password: string;
    type: number;
    tell: string;
    mail: string;
    orgname: string;
    orgadr: string;
    orgmatnum: string;
    foto: string;
    status: number;
    newmessage: Message;
    activechat: Chat;
    _id: string;
}