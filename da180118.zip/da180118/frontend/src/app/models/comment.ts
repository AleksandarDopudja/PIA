export class Comment{
    username: string;
    name: string;
    time: Date;
    txt: string;
    _id: string;
}