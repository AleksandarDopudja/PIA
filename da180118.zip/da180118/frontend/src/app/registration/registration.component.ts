import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private service: UserService, private router: Router) {
   }

  ngOnInit(): void {
  }

  @ViewChild('Image') imgType:ElementRef;

  firstname: string = '';
  lastname: string = '';
  username: string = '';
  password: string = '';
  password2: string = '';
  mail: string = '';
  tell: string = '';
  orgname: string = '';
  orgadress: string = '';
  orgmatnum: string = '';
  type: number = 0;
  foto: string = '';

  width:number = 0;
  height:number = 0;

  myCheckbox: boolean = false;

  message: string = '';

  
  url: any; //Angular 11, for stricter type
	msg = "";
	
	//selectFile(event) { //Angular 8
	selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'Izaberite sliku!';
			return;
		}

    var name = event.target.files[0].name;
    var type = event.target.files[0].type;
    var size = event.target.files[0].size;
    var modifiedDate = event.target.files[0].lastModifiedDate;

    let format = type.split("/");
    //console.log(format[1])

    if(format[1]!='png' && format[1]!='jpg'){
      this.msg = 'Los format!(samo JPG/PNG)';
			return;
    }
		
		var mimeType = event.target.files[0].type;
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Samo su podrzane slike!";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {

			this.msg = "";
			this.url = reader.result; 

      
      console.log(this.url.width);
		}
	}

  register(){

    this.type=1;
    if(this.myCheckbox==true) {
      this.type=2;
    }

    //let format = Image.value.split(".");
    //let slika = Image.value.split("\\");
    this.foto = this.url;

    if(this.firstname=='' || this.lastname=='' || this.username=='' || this.password=='' || this.password2=='' || this.mail==''){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.myCheckbox==true && (this.orgname==''||this.orgadress==''||this.orgmatnum=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.password!=this.password2 ){
      this.message = "Neispravna potvrda lozinke!"
      return false;
    }

    if(this.tell!=""){
      if(/^\d\d\d-\d\d\d-\d{3,4}$/.test(this.tell) == false) {
        this.message = 'Unesite telefon u formatu: xxx-xxx-xxx(x)';
        return false;
      }
    }

    if(/\w@\w/.test(this.mail) == false) {
      this.message = 'Unesite validan mejl sa @!';
      return false;
    }

    if(this.password.length < 8) {
      this.message = 'Lozinka mora sadržati bar 8 karaktera!';
      return false;
    }
    if(this.password.length > 16) {
      this.message = 'Lozinka ne sme sadrzati vise od 16 karaktera!';
      return false;
    }
    if(/[a-z]/.test(this.password) == false) {
      this.message = 'Lozinka mora počinjati slovom!';
      return false;
    }
    if(/[A-Z]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
      return false;
    }
    if(/[\d{+}]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 broj!';
      return false;
    }
    if(/[^a-zA-Z\d]/.test(this.password) == false ) {
      this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
      return false;
    }

    if(this.username.length<5){
      this.message = 'Korisnicko ime mora da sadrzi vise od 4 karaktera!';
      return false;
    }

    
    this.service.doesUserExist(this.username).subscribe((val:boolean)=>{
      //alert(val);
      if(val==true){
        this.message = "Korisnocko ime vec u upotrebi!"
        return false;
      }else{

        this.service.doesMailInUse(this.mail).subscribe((val2:boolean)=>{

          if(val2==true){
            this.message = "Mail vec u upotrebi!!"
            return false;
          }else{

            this.service.register(this.firstname, this.lastname, this.username, this.password,this.tell,this.mail, this.type,this.orgname, this.orgadress, this.orgmatnum, this.foto, 0).subscribe((resp)=>{
            
              if(resp['message']=='user added'){
                alert("Uspesno ste poslali zahtev za registraciju! Adminstrator ce u najkracem roku obraditi vas zahtev!");
                this.router.navigate(['']);
                return true;
              }else{
                alert("error");
                return false;
              }
            });
            return false;
          }
        })

        return false;
      }
    })

    return false;
  }



}
