import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-loginadmin',
  templateUrl: './loginadmin.component.html',
  styleUrls: ['./loginadmin.component.css']
})
export class LoginadminComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
  }

  username: string = "";
  password: string = "";

  message: string = "";

  login(){

    if(this.username == "" || this.password == ""){
      this.message = "Nisu uneta sva polja!";
    }
    else{
      this.userService.login(this.username, this.password).subscribe((user:User)=>{

        sessionStorage.setItem('currlogin',JSON.stringify(user));
        if(user){
            if(user.status==1){
              if(user.type==3){
                this.router.navigate(['../adminpage']);
              }else{
                alert("Login namenjen iskljucivo za administratore!");
              }
            }else if(user.status==0){
              alert("Vas zahtev za registraciju jos nije obradjen od strane administratora!");
            }
        }
        else {
          //alert('Bad data');
          this.message = "Neispravno uneti podac!";
        }
      })
    }
  }
}
