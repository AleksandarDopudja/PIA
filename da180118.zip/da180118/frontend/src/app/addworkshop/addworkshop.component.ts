import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { WorkshopService } from '../services/workshop.service';

@Component({
  selector: 'app-addworkshop',
  templateUrl: './addworkshop.component.html',
  styleUrls: ['./addworkshop.component.css']
})
export class AddworkshopComponent implements OnInit {

  constructor(private service: WorkshopService) { }

  currlogin: User;

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    this.urls=[];
  }

  urls = [];
 
  selectFiles(event){
    
    if(event.target.files){
  
      for(let i=0;i<File.length;i++){
  
        let reader = new FileReader()
  
      reader.readAsDataURL(event.target.files[i])
  
      reader.onload = (event: any) => {
          this.urls.push(event.target.result)
      }
  
      }
    
    }  
  
  }

  url: any;
  msg: string;

  selectFile(event: any) { //Angular 11, for stricter type
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'You must select an image';
			return;
		}
		
		var mimeType = event.target.files[0].type;
		
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Only images are supported";
			return;
		}
		
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {
			this.msg = "";
			this.url = reader.result; 
      //alert(this.url)
      //sessionStorage.setItem('url', this.url);
		}
	}

  name: string;
  place: string;
  date: string;
  shortinfo: string;
  info: string;
  capacity: number;
  time: string;

  sendReqWorkshop(){
    this.service.insertWorkshop(this.url, this.name, this.date, this.place, this.shortinfo, this.info, this.urls, this.currlogin.username, this.capacity).subscribe(resp=>{
      alert("Dodato!");
    })
  }

}
