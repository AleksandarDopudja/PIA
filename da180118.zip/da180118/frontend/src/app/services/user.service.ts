import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  login(username, password){
    
    const data={
      username: username,
      password: password
    }

    return this.http.post(`${this.url}/users/login`, data);
  }

  register(firstname,lastname,username, password, tell, mail, type, orgname, orgadr, orgmatnum, foto, status){

    const data={
      firstname: firstname,
      lastname: lastname,
      username: username,
      password: password,
      mail: mail,
      type: type,
      orgname: orgname,
      orgadr: orgadr,
      orgmatnum: orgmatnum,
      foto: foto,
      tell: tell,
      status: status
    }

    return this.http.post(`${this.url}/users/register`, data);
  }

  getPartWorkshops(username){

    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/getPartWorkshops`, data);

  }

  getAllLikes(username){

    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/getAllLikes`, data);
  }

  deleteLike(username,name){

    const data={
      username: username,
      name: name
    }

    return this.http.post(`${this.url}/users/deleteLike`, data);

  }

  getAllComments(username){

    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/getAllComments`, data);
  }

  deleteComment(id){
    const data={
      id: id
    }

    return this.http.post(`${this.url}/users/deleteComment`, data);
  }

  editComment(id, txt){
    const data={
      id: id,
      txt: txt
    }

    return this.http.post(`${this.url}/users/editComment`, data);
  }

  getAllChats(username){
    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/getChats`, data);
  }

  getOrgChats(orgusername){
    const data={
      orgusername: orgusername
    }

    return this.http.post(`${this.url}/users/getOrgChats`, data);
  }

  insertMessage(id, message){
    const data={
      id: id,
      message: message
    }

    return this.http.post(`${this.url}/users/insertMessage`, data);
  }

  getParticipations(username){

    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/getParticipations`, data);
    
    //getParticipations
  }

  insertParticipations(username, name, date, org, foto, place, shortinfo){

    const data={
      name: name,
      username: username,
      date: date,
      org: org,
      foto: foto,
      place: place,
      shortinfo: shortinfo
    }

    return this.http.post(`${this.url}/users/insertParticipations`, data);
    
    //getParticipations
  }

  existParticipation(username, name, date){

    const data={
      username: username,
      name: name,
      date: date
    }

    return this.http.post(`${this.url}/users/existParticipations`, data);
  }

  getUsers(usernames){
    const data={
      usernames: usernames
    }

    return this.http.post(`${this.url}/users/getUsers`, data);
  }

  doesUserExist(username){
    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/doesUserExist`, data);
  }

  doesMailInUse(mail){
    const data={
      mail: mail
    }

    return this.http.post(`${this.url}/users/doesMailInUse`, data);

  }

  changePassword(username, newpassword){

    const data={
      username: username,
      password: newpassword
    }

    return this.http.post(`${this.url}/users/changePassword`, data);
  }

  getUsersParticipants(){
    return this.http.get(`${this.url}/users/getUsersParticipants`);
  }

  getUsersOrganizers(){
    return this.http.get(`${this.url}/users/getUsersOrganizers`);
  }

  changeUserDetails(id, firstname, lastname, username, password, mail, type, orgname, orgadr, orgmatnum, foto, tell, status){

    const data={
      id: id,
      firstname: firstname,
      lastname: lastname,
      username: username,
      password: password,
      mail: mail,
      type: type,
      orgname: orgname,
      orgadr: orgadr, 
      orgmatnum: orgmatnum,
      foto: foto,
      tell: tell, 
      status: status

    }

    return this.http.post(`${this.url}/users/changeUserDetails`, data);

    //changeUserDetails
  }

  deleteUser(username){
    const data={
      username: username
    }

    return this.http.post(`${this.url}/users/deleteUser`, data);
  }

  sortByName(participations){
    return participations.sort((a, b) => {
      if (a.name < b.name) {
          return -1;
      }
      if (a.name > b.name) {
          return 1;
      }
      return 0;});
  }

  sortByDate(participations){
    return participations.sort((a,b)=>{
      if(a.date<b.date){
        return -1;
      }else if(a.birthdate==b.birthdate){
        return 0;
      }else{
        return 1;
      }
    })
  }

  sortByPlace(participations){
    return participations.sort((a, b) => {
      if (a.place < b.place) {
          return -1;
      }
      if (a.place > b.place) {
          return 1;
      }
      return 0;});
  }

  getReqUsers(){

    return this.http.get(`${this.url}/users/getUserRequests`);
    //getUserRequests
  }

  setStatusUser(username, status){
    const data={
      username: username,
      status: status
    }

    return this.http.post(`${this.url}/users/setStatusUser`, data);
  }

  deleteParticipations(name, date){
    const data={
      name: name,
      status: date
    }

    return this.http.post(`${this.url}/users/deleteParticipations`, data);
  }
}
