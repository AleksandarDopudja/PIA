import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WorkshopService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  getAllWorkshops(){
    return this.http.get(`${this.url}/workshops/getWorkshops`);
  }

  getMyWorkshops(username){
    const data={
      username: username
    }

    return this.http.post(`${this.url}/workshops/getMyWorkshops`, data);
  }

  insertWorkshop(mainphoto, name, date, place, shortinfo, info, galery, org, capacity){
    const data={
      mainphoto: mainphoto,
      name: name,
      date: date,
      place: place,
      shortinfo: shortinfo,
      info: info,
      galery: galery,
      org: org,
      capacity: capacity,
      status: "onwait"
    }

    return this.http.post(`${this.url}/workshops/insertWorkshop`, data);
  }

  search(place, name, workshops){

    if(place!="" && name!=""){
      return workshops.filter(ws=>ws.name.includes(name) && ws.place==place);
    }else if(place!=""){
      return workshops.filter(ws=>ws.place==place);
    }else if(name!=""){
      return workshops.filter(ws=>ws.name.includes(name));
    }else{
      return workshops;
    }
  }

  sortByDate(workshops){
    return workshops.sort((a,b)=>{
      if(a.date<b.date){
        return -1;
      }else if(a.birthdate==b.birthdate){
        return 0;
      }else{
        return 1;
      }
    })
  }

  sortByName(workshops){
    return workshops.sort((a, b) => {
      if (a.name < b.name) {
          return -1;
      }
      if (a.name > b.name) {
          return 1;
      }
      return 0;});
  }

  //setStatusWorkshop

  setStatusWorkshop(id, status){
    const data={
      id: id,
      status: status
    }

    return this.http.post(`${this.url}/workshops/setStatusWorkshop`, data);
  }

  deleteWorkshop(id){
    const data={
      id: id,
    }

    return this.http.post(`${this.url}/workshops/deleteWorkshop`, data);

  }
}
