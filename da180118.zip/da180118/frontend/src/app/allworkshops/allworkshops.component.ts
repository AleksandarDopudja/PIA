import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { WorkshopService } from '../services/workshop.service';
import { UserpageComponent } from '../userpage/userpage.component';

@Component({
  selector: 'app-allworkshops',
  templateUrl: './allworkshops.component.html',
  styleUrls: ['./allworkshops.component.css']
})
export class AllworkshopsComponent implements OnInit {

  constructor(private service: WorkshopService) { }

  currlogin: User;
  workshops: Workshop[] = [];
  places: string[] = [];

  searchname: string = "";
  searchplace: string = "";
  orgworkshops: Workshop[] = [];

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
      if(this.currlogin.type == 1 || this.currlogin.type == 0 || this.currlogin.type == 3){
      this.service.getAllWorkshops().subscribe((workshops: Workshop[])=>{
        if(workshops){
          this.workshops = workshops;
          this.orgworkshops = workshops;

          for(let i =0;i<this.workshops.length;i++){
            if(!this.places.includes(this.workshops[i].place))this.places.push(this.workshops[i].place);
          }
        }
      })
    }else if(this.currlogin.type == 2){
      
      this.service.getAllWorkshops().subscribe((workshops:Workshop[])=>{
        this.workshops = workshops;
        this.orgworkshops = workshops;

        for(let i =0;i<this.workshops.length;i++){
          if(!this.places.includes(this.workshops[i].place))this.places.push(this.workshops[i].place);
        }
      })
    }
  }

  search(){
    //alert(this.searchplace);
      this.workshops = this.orgworkshops;
      if(this.searchplace!="" || this.searchname!="")this.workshops = this.service.search(this.searchplace, this.searchname, this.workshops);
    
  }

  sortbydate(){
    this.workshops = this.service.sortByDate(this.workshops);
    this.searchplace = "";
    this.searchname="";
  }

  sortbyname(){
    this.workshops = this.service.sortByName(this.workshops);
    this.searchplace = "";
    this.searchname="";
  }

  addworkshop(){
    
  }

}
