import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    this.username = this.currlogin.username;
  }

  currlogin: User;
  username: string = '';
  oldpassword: string = '';
  newpassword: string = '';
  newpassword2: string = '';
  message: string = '';

  change(){

    if(this.newpassword.length < 8) {
      this.message = 'Lozinka mora sadržati bar 8 karaktera!';
      return false;
    }
    if(this.newpassword.length > 16) {
      this.message = 'Lozinka ne sme sadrzati vise od 16 karaktera!';
      return false;
    }
    if(/[a-z]/.test(this.newpassword) == false) {
      this.message = 'Lozinka mora počinjati slovom!';
      return false;
    }
    if(/[A-Z]/.test(this.newpassword) == false) {
      this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
      return false;
    }
    if(/[\d{+}]/.test(this.newpassword) == false) {
      this.message = 'Lozinka mora sadržati bar 1 broj!';
      return false;
    }
    if(/[^a-zA-Z\d]/.test(this.newpassword) == false ) {
      this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
      return false;
    }
    if(this.newpassword!=this.newpassword2){
      this.message = 'Ponovni unos lozinke pogresan!'
      return false;
    }

    this.service.login(this.username, this.oldpassword).subscribe((user: User)=>{
      if(user!=null){
        this.service.changePassword(this.username, this.newpassword).subscribe(resp=>{
          //alert(resp['message']);
          alert("Lozinka uspesno promenjena!")
          this.router.navigate(['']);
        })
      }else{
        this.message = "Pogresno uneta stara lozinka!"
        return false;
      }
      return false;
    })

    return false;
  }
}
