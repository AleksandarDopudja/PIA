import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserpageComponent } from './userpage/userpage.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { WorkshopComponent } from './workshop/workshop.component';
import { AllworkshopsComponent } from './allworkshops/allworkshops.component';
import { ProfileComponent } from './profile/profile.component';
import { WorkshopdetailsComponent } from './workshopdetails/workshopdetails.component';
import { WorkshopproposalComponent } from './workshopproposal/workshopproposal.component';
import { OrganizerComponent } from './organizer/organizer.component';
import { OrganizerprofileComponent } from './organizerprofile/organizerprofile.component';
import { AddworkshopComponent } from './addworkshop/addworkshop.component';
import { WorkshoporganizerComponent } from './workshoporganizer/workshoporganizer.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { AdminworkshopsComponent } from './adminworkshops/adminworkshops.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    WelcomepageComponent,
    UserpageComponent,
    FooterComponent,
    NavbarComponent,
    FileUploadComponent,
    WorkshopComponent,
    AllworkshopsComponent,
    ProfileComponent,
    WorkshopdetailsComponent,
    WorkshopproposalComponent,
    OrganizerComponent,
    OrganizerprofileComponent,
    AddworkshopComponent,
    WorkshoporganizerComponent,
    ChangepasswordComponent,
    LoginadminComponent,
    AdminpageComponent,
    UserdetailsComponent,
    AdminworkshopsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
