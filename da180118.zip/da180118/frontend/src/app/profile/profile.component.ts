import { Component, Input, OnInit } from '@angular/core';
import { Like } from '../models/like';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { Comment } from '../models/comment';
import { UserService } from '../services/user.service';
import { Chat } from '../models/chat';
import { Message } from '../models/message';
import { Participation } from '../models/participation';
import { WorkshopService } from '../services/workshop.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private service: UserService, private serviceWorkshops: WorkshopService) { }

  loginuser: User;

  mod: number = 0;
  mod2: number = 0;

  workshops: Workshop[] = [];
  likes: Like[] = [];
  comments: Comment[] = [];

  editpic : string;
  editpic1: string = 'edit.png';
  editpic2: string = 'check.png';

  editmode: Comment = null;
  editedText: string = "";

  chats: Chat[]=[];
  activechat: Chat = null;
  messages: Message[] = [];

  participations: Participation[] = [];

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.editpic = this.editpic1;
    this.getParticipations();
  }

  setMod(i){
    if(i==1){
      this.getPartWorkshops();
    }else if(i==2){

    } else if(i==3){
      this.getAllChats();
    }
    this.mod = i;
  }

  setMod2(i){
    if(i==1){
      this.getAllLikes();
    }else if(i==2){
      this.getAllComments();
    }
    this.mod2 = i;
  }

  getParticipations(){
    this.service.getParticipations(this.loginuser.username).subscribe((part:Participation[])=>{
      this.participations = part;
    })
  }

  getPartWorkshops(){
    //alert(1);

    //alert(this.loginuser.username);
    this.service.getPartWorkshops(this.loginuser.username).subscribe((workshops: Workshop[])=>{
      this.workshops = workshops;
      //alert(this.workshops.length);
    })
  }

  getAllLikes(){
    this.service.getAllLikes(this.loginuser.username).subscribe((likes: Like[])=>{
      this.likes = likes;
    })
  }

  deleteLike(l:Like){
    //alert(l._id);
    this.service.deleteLike(this.loginuser.username, l.name).subscribe((resp)=>{
      if(resp['message']=='ok'){
        //alert("ok");
        this.getAllLikes();
      }
    })
  }

  getAllComments(){
  
    this.service.getAllComments(this.loginuser.username).subscribe((comments: Comment[])=>{
      this.comments = comments;
      //alert(this.comments.length);
    })
  }

  deleteComment(c:Comment){
    this.service.deleteComment(c._id).subscribe((resp)=>{
      if(resp['message']=='ok'){
        //alert("ok");
        this.getAllComments();
      }
    })
  }

  editComment(c:Comment){
    if(c==this.editmode){
      //alert(this.editedText)
      this.service.editComment(c._id, this.editedText).subscribe((resp)=>{
        if(resp['message']=='ok'){
          //alert("ok");
          this.getAllComments();
        }else{
          alert("err");
        }
      });
      this.editmode = null;
    }else{
      this.editmode = c;
    }
    this.editedText = this.editmode.txt; 
  }

  getAllChats(){
    this.service.getAllChats(this.loginuser.username).subscribe((chats: Chat[])=>{
      this.chats = chats;
    })

    
  }

  activateChat(c:Chat){
    //alert(c.messages[0].txt);
    this.activechat = c;
    this.messages = c.messages;

    for(let i = 0; i<this.messages.length;i++){
      this.messages[i].time = new Date(this.messages[i].time);
    }
    //alert(this.messages.length);
  }

  textToSend: string;
  newMess: Message = null;

  sendMessage(){

    this.newMess = new Message();

    this.newMess.name = this.loginuser.username;
    this.newMess.txt = this.textToSend;
    this.newMess.time = new Date();

    this.messages.push(this.newMess);

    this.service.insertMessage(this.activechat._id, this.newMess).subscribe((ress)=>{
      if(ress['message'] == 'ok'){
        alert('ok');
      }
    })

    this.textToSend="";

  } 

  sortByName() {
    this.participations = this.service.sortByName(this.participations);
  }

  sortByDate() {
    this.participations = this.service.sortByDate(this.participations);
  }

  sortByPlace() {
    this.participations = this.service.sortByPlace(this.participations);
  }

}
