import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkshoporganizerComponent } from './workshoporganizer.component';

describe('WorkshoporganizerComponent', () => {
  let component: WorkshoporganizerComponent;
  let fixture: ComponentFixture<WorkshoporganizerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkshoporganizerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkshoporganizerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
