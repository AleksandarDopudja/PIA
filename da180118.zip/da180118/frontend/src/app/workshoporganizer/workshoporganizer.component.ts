import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-workshoporganizer',
  templateUrl: './workshoporganizer.component.html',
  styleUrls: ['./workshoporganizer.component.css']
})
export class WorkshoporganizerComponent implements OnInit {

  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.exists = "false";
    this.workshop = JSON.parse(sessionStorage.getItem('currworkshop'));
    this.restartWorkshop = JSON.parse(JSON.stringify(this.workshop));
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    this.workshop.date = new Date(this.workshop.date);
    this.datestr = this.workshop.date.getFullYear()+"-"+(this.workshop.date.getMonth()+1)+"-"+this.workshop.date.getDate();
    this.time = this.workshop.date.getHours()+":"+this.workshop.date.getMinutes();
  }

  workshop: Workshop;
  restartWorkshop: Workshop;
  currlogin: User;
  exists: string;
  datestr: string;
  time: string;
  
  editmode: number = -1;


  save(){
   
  }

  setmode(n:number){
    if(this.editmode==n) this.editmode = -1;
    else this.editmode = n;
  }

  restart(n : number){
    if(n==1){
      this.workshop.name = this.restartWorkshop.name;
    }else if (n==2){
      this.workshop.place = this.restartWorkshop.place;
    }else if(n==3){
      this.datestr = this.workshop.date.getFullYear()+"-"+(this.workshop.date.getMonth()+1)+"-"+this.workshop.date.getDate();
    }else if(n==4){
      this.workshop.info = this.restartWorkshop.info;
    }else if(n==5){
      this.workshop.shortinfo = this.restartWorkshop.shortinfo;
    }else if(n==6){
      this.time = this.workshop.date.getHours()+":"+this.workshop.date.getMinutes();
    }
  }

}
