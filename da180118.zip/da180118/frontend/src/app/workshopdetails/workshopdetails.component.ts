import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { UserService } from '../services/user.service';
import { WorkshopService } from '../services/workshop.service';

@Component({
  selector: 'app-workshopdetails',
  templateUrl: './workshopdetails.component.html',
  styleUrls: ['./workshopdetails.component.css']
})
export class WorkshopdetailsComponent implements OnInit {

  constructor(private service: UserService, private serv: WorkshopService, private router: Router) { }

  ngOnInit(): void {
    this.exists = "false";
    this.workshop = JSON.parse(sessionStorage.getItem('currworkshop'));
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'))
    this.workshop.date = new Date(this.workshop.date);
    this.service.existParticipation(this.currlogin.username, this.workshop.name, this.workshop.date).subscribe((resp)=>{
      this.exists = resp['message'];
    })
  }

  workshop: Workshop;
  currlogin: User;
  exists: string;


  insertParticipation(){
    this.service.insertParticipations(this.currlogin.username, this.workshop.name, this.workshop.date, this.workshop.org, this.workshop.mainphoto, this.workshop.place, this.workshop.shortinfo).subscribe(resp=>{
      alert(resp['message']);
    });

    this.ngOnInit();
  }

  setStatus(n:number){
    
    if(n==1){
      this.serv.setStatusWorkshop(this.workshop._id, 'active').subscribe(resp=>{
        this.router.navigate(['/adminworkshops']);
      })
    }else{
      this.serv.setStatusWorkshop(this.workshop._id, 'x').subscribe(resp=>{
        this.router.navigate(['/adminworkshops']);
      })
    }
  }
}
