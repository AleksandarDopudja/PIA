import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {

  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.curruser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getUsersParticipants().subscribe((users: User[])=>{
      this.partUsers = users;
    })

    this.service.getUsersOrganizers().subscribe((users: User[])=>{
      this.orgUsers = users;
    })

    this.service.getReqUsers().subscribe((users:User[])=>{
      this.reqUsers = users;
    })
  }

  curruser: User;
  partUsers: User[] = [];
  orgUsers: User[] = [];
  reqUsers: User[] = [];
  active: User[] = [];
  n: number = 0;

  activate(n:number){
    this.n = n;
    if(n==1){
      this.active = this.partUsers;
    }else if(n==2){
      this.active = this.orgUsers;
    }else if(n==3){
      this.active = this.reqUsers;
    }
  }

  setuser(u: User){
    sessionStorage.setItem('userdetails', JSON.stringify(u));
  }

  addUser(){
    //let user = new User();
    sessionStorage.setItem('userdetails', null);
  }

  acc(u:User){
    this.service.setStatusUser(u.username, 1).subscribe(resp=>{
      this.ngOnInit();
        this.active = this.reqUsers;
      
    })
  }

  dec(u:User){
    this.service.setStatusUser(u.username, -1).subscribe(resp=>{
      this.ngOnInit();
        this.active = this.reqUsers;
      
    })
  }

}
