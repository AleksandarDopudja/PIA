import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminworkshops',
  templateUrl: './adminworkshops.component.html',
  styleUrls: ['./adminworkshops.component.css']
})
export class AdminworkshopsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  activate(n:number){

  }

}
