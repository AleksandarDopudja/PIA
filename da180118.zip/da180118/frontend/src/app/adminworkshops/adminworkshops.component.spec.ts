import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminworkshopsComponent } from './adminworkshops.component';

describe('AdminworkshopsComponent', () => {
  let component: AdminworkshopsComponent;
  let fixture: ComponentFixture<AdminworkshopsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminworkshopsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminworkshopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
