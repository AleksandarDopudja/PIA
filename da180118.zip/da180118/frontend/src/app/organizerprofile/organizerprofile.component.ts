import { Component, OnInit } from '@angular/core';
import { Chat } from '../models/chat';
import { Message } from '../models/message';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-organizerprofile',
  templateUrl: './organizerprofile.component.html',
  styleUrls: ['./organizerprofile.component.css']
})
export class OrganizerprofileComponent implements OnInit {

  constructor(private service: UserService) { }

  loginuser: User;
  chats: Chat[] = [];
  workshopsnames: string[] = [];
  workshop : string;

  users: string[]=[];
  usersobj: User[]=[];

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.getOrgChats();
  }

  getOrgChats(){
    this.service.getOrgChats(this.loginuser.username).subscribe((chats: Chat[])=>{
      this.chats = chats;
      for(let i =0; i<this.chats.length;i++){
        if(this.workshopsnames.includes(this.chats[i].workshopname)==false){
          this.workshopsnames.push(this.chats[i].workshopname);
        }
      }

    })
  }

  currworkshop(w:string){
    this.users = [];
    this.workshop = w;

    for(let i =0; i<this.chats.length;i++){
      if(this.users.includes(this.chats[i].username)==false && this.chats[i].workshopname == this.workshop){
        this.users.push(this.chats[i].username);
      }
    }

    this.service.getUsers(this.users).subscribe((users: User[])=>{
      this.usersobj = users;
    })
  }

  activeUsers: User[] = [];

  openChat(u:User){
    if(this.activeUsers.includes(u)){
      this.activeUsers.splice(this.activeUsers.findIndex(usr=>usr.username==u.username),1);
      u.activechat = null;
    }else{
      this.activeUsers.push(u);
      u.activechat = this.chats.find(chat=>chat.username==u.username && chat.workshopname==this.workshop);
      //this.activeChat = this.chats.find(chat=>chat.username==u.username && chat.workshopname==this.workshop);
    }
  }

  textToSend: string;

  sendMessage(u:User){

    //this.activeChat = this.chats.find(chat=>chat.username==u.username && chat.workshopname==this.workshop);

    u.newmessage = new Message();

    u.newmessage.name = this.loginuser.username;
    u.newmessage.txt = this.textToSend;
    u.newmessage.time = new Date();

    u.activechat.messages.push(u.newmessage);

    this.service.insertMessage(u.activechat._id, u.newmessage).subscribe((ress)=>{
      if(ress['message'] == 'ok'){
        alert('ok');
      }
    })

    this.textToSend="";

  }

}
