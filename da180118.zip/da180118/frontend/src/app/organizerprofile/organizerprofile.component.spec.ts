import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganizerprofileComponent } from './organizerprofile.component';

describe('OrganizerprofileComponent', () => {
  let component: OrganizerprofileComponent;
  let fixture: ComponentFixture<OrganizerprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganizerprofileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrganizerprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
