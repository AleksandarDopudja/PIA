import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Workshop } from '../models/workshop';
import { UserpageComponent } from '../userpage/userpage.component';

@Component({
  selector: 'app-workshop',
  templateUrl: './workshop.component.html',
  styleUrls: ['./workshop.component.css']
})
export class WorkshopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    this.workshop.date = new Date(this.workshop.date);
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  loginuser: User;

  @Input() workshop: Workshop;
  
  setworkshop(){
    sessionStorage.setItem('currworkshop', JSON.stringify(this.workshop));
  }

}
