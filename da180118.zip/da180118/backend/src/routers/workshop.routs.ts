import express from 'express';
import { WorkshopController } from '../controllers/workshop.controller';

const workshopRouter = express.Router();

workshopRouter.route('/getWorkshops').get(
    (req,res)=>new WorkshopController().getWorkshops(req,res)
);

workshopRouter.route('/insertWorkshop').post(
    (req,res)=>new WorkshopController().insertWorkshop(req,res)
);

workshopRouter.route('/getMyWorkshops').post(
    (req,res)=>new WorkshopController().getMyWorkshops(req,res)
);

workshopRouter.route('/setStatusWorkshop').post(
    (req,res)=>new WorkshopController().setStatusWorkshop(req,res)
);


workshopRouter.route('/deleteWorkshop').post(
    (req,res)=>new WorkshopController().deleteWorkshop(req,res)
);

export default workshopRouter;