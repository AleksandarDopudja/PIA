import express from 'express';
import { UserController } from '../controllers/user.controller';

const userRouter = express.Router();

userRouter.route('/login').post(
    (req,res)=>new UserController().login(req,res)
);

userRouter.route('/register').post(
    (req,res)=>new UserController().register(req,res)
);

userRouter.route('/getPartWorkshops').post(
    (req,res)=>new UserController().getPartWorkshops(req,res)
);

userRouter.route('/getParticipations').post(
    (req,res)=>new UserController().getParticipations(req,res)
);

userRouter.route('/insertParticipations').post(
    (req,res)=>new UserController().insertParticipation(req,res)
);

userRouter.route('/existParticipations').post(
    (req,res)=>new UserController().existParticipation(req,res)
);

userRouter.route('/getAllLikes').post(
    (req,res)=>new UserController().getAllLikes(req,res)
);

userRouter.route('/deleteLike').post(
    (req,res)=>new UserController().deleteLike(req,res)
);

userRouter.route('/getAllComments').post(
    (req,res)=>new UserController().getAllComments(req,res)
);

userRouter.route('/deleteComment').post(
    (req,res)=>new UserController().deleteComment(req,res)
);

userRouter.route('/editComment').post(
    (req,res)=>new UserController().editComment(req,res)
);

userRouter.route('/getChats').post(
    (req,res)=>new UserController().getChats(req,res)
);

userRouter.route('/getOrgChats').post(
    (req,res)=>new UserController().getOrgChats(req,res)
);

userRouter.route('/insertMessage').post(
    (req,res)=>new UserController().insertMessage(req,res)
);

userRouter.route('/getUsers').post(
    (req,res)=>new UserController().getUsers(req,res)
);

userRouter.route('/doesUserExist').post(
    (req,res)=>new UserController().doesUserExist(req,res)
);

userRouter.route('/doesMailInUse').post(
    (req,res)=>new UserController().doesMailInUse(req,res)
);

userRouter.route('/changePassword').post(
    (req,res)=>new UserController().changePassword(req,res)
);

userRouter.route('/getUsersParticipants').get(
    (req,res)=>new UserController().getUsersParticipants(req,res)
);

userRouter.route('/getUsersOrganizers').get(
    (req,res)=>new UserController().getUsersOrganizers(req,res)
);

userRouter.route('/changeUserDetails').post(
    (req,res)=>new UserController().changeUserDetails(req,res)
);

userRouter.route('/deleteUser').post(
    (req,res)=>new UserController().deleteUser(req,res)
);

userRouter.route('/getUserRequests').get(
    (req,res)=>new UserController().getUserRequests(req,res)
);

userRouter.route('/setStatusUser').post(
    (req,res)=>new UserController().setStatusUser(req,res)
);

userRouter.route('/deleteParticipations').post(
    (req,res)=>new UserController().deleteParticipations(req,res)
);

userRouter.route('/checkUser').post(
    (req,res)=>new UserController().checkUser(req,res)
);


export default userRouter;