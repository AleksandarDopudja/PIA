import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Participation = new Schema({
    username: {
        type: String
    },
    name: {
        type: String
    },
    date: {
        type: String
    },
    foto: {
        type: String
    }, 
    org: {
        type: String
    },
    place: {
        type: String
    },
    shortinfo: {
        type: String
    }
})

export default mongoose.model('Participation', Participation, 'participations');