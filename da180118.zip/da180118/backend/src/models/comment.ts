import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Comment = new Schema({
    username: {
        type: String
    },
    name: {
        type: String
    },
    time: {
        type: Date
    },
    txt: {
        type: String
    }
})

export default mongoose.model('Comment', Comment, 'comments');