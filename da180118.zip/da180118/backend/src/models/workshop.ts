import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Workshop = new Schema({
    mainphoto: {
        type: String
    },
    name: {
        type: String
    },
    date: {
        type: String
    },
    place: {
        type: String
    },
    shortinfo: {
        type: String
    },
    info:{
        type: String
    },
    galery:{
        type: Array
    },
    org:{
        type: String
    },
    capacity:{
        type: Number
    },
    status: {
        type: String
    }
})

export default mongoose.model('Workshop', Workshop, 'workshops');