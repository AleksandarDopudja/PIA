import mongoose from "mongoose";

const Schema = mongoose.Schema;

let User =new Schema({
    firstname: {
        type: String
    },
    lastname: {
        type: String
    }, 
    username: {
        type: String
    },
    password: {
        type: String
    },
    mail: {
        type: String
    },
    type: {
        type: Number
    },
    orgname: {
        type: String
    },
    orgadr: {
        type: String
    },
    orgmatnum: {
        type: String
    },
    foto: {
        type: String
    },
    tell: {
        type: String
    },
    status: {
        type: Number
    }
})

export default mongoose.model('User', User, 'users');