import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Chat = new Schema({
    orgusername: {
        type: String
    },
    username:{
        type: String
    },
    workshopname: {
        type: String
    },
    time: {
        type: Date
    },
    messages: {
        type: Array
    }
})

export default mongoose.model('Chat', Chat, 'chat');