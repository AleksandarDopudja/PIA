import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Like = new Schema({
    username: {
        type: String
    },
    name: {
        type: String
    },
    time: {
        type: Date
    }
})

export default mongoose.model('Like', Like, 'likes');