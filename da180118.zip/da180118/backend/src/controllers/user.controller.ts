import * as express from 'express';
import User from '../models/user'
import Participation from '../models/participation'
import Workshop from '../models/workshop'
import Likes from '../models/like'
import Comments from '../models/comment'
import Chats from '../models/chat'

export class UserController{

    checkUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let date = new Date();

        Participation.findOne({'username':username, 'date':{$gt:date}}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user!=null);
        })
    }

    doesUserExist = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        User.findOne({'username':username}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user!=null);
        })
    }

    doesMailInUse = (req: express.Request, res: express.Response)=>{
        let mail = req.body.mail;

        User.findOne({'mail':mail}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user!=null);
        })
    }

    changePassword = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let newpassword = req.body.password;

        User.updateOne({'username':username}, {$set: {'password': newpassword}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    setStatusUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let status = req.body.status;

        User.updateOne({'username':username}, {$set: {'status': status}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    login = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let password = req.body.password;

        User.findOne({'username':username, 'password':password}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user);
        })
    }

    register = (req: express.Request, res: express.Response)=>{
        
        let user = new User({
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            username: req.body.username,
            password: req.body.password,
            mail: req.body.mail,
            type: req.body.type,
            orgname: req.body.orgname,
            orgadr: req.body.orgadr,
            orgmatnum: req.body.orgmatnum,
            foto: req.body.foto,
            tell: req.body.tell,
            status: req.body.status
        })

        User.insertMany(user);
        res.status(200).json({'message':'user added'})
    }

    changeUserDetails = (req: express.Request, res: express.Response)=>{

        let id = req.body.id;
        let firstname = req.body.firstname;
        let lastname = req.body.lastname;
        let username  = req.body.username;
        let password = req.body.password;
        let mail =  req.body.mail;
        let type  = req.body.type;
        let orgname = req.body.orgname;
        let orgadr = req.body.orgadr;
        let orgmatnum = req.body.orgmatnum;
        let foto =  req.body.foto;
        let tell = req.body.tell;
        let status = req.body.status;
        //console.log(id);
        //console.log(mail);

        User.updateOne({'_id':id}, {$set: {'firstname': firstname,'lastname':lastname,'username':username, 'password':password, 'mail':mail, 'type':type, 'orgname':orgname, 'orgadr':orgadr, 'orgmatnum':orgmatnum, 'foto':foto, 'tell':tell, 'status': status }}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    deleteUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        User.deleteOne({'username':username}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getUserRequests = (req: express.Request, res: express.Response)=>{

        User.find({'status': 0}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getUsers = (req: express.Request, res: express.Response)=>{
        let usernames = req.body.usernames;

        User.find({'username':{$in:usernames}}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getUsersParticipants = (req: express.Request, res: express.Response)=>{

        let status = [1,2]
        User.find({'status':{$in:status}, 'type': 1}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getUsersOrganizers = (req: express.Request, res: express.Response)=>{

        let status = [1,2]
        User.find({'status':{$in:status}, 'type': 2}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    insertParticipation = (req: express.Request, res: express.Response)=>{
        let participation = new Participation({
            username: req.body.username,
            name: req.body.name,
            date: req.body.date, 
            foto: req.body.foto,
            org: req.body.org,
            place: req.body.place,
            shortinfo: req.body.shortinfo
        })

        Participation.insertMany(participation);
        res.status(200).json({'message':'user added'})
    }

    getPartWorkshops = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let s = [];
        
        Participation.find({'username':username}, (err, part)=>{
            if(err)console.log(err);
            else{
                let a=[];
                for(let i = 0 ; i<part.length;i++){
                    a.push(part[i].name);
                }
                Workshop.find({'name':{$in:a}}, (err, workshops)=>{
                    if(err) console.log(err);
                    else {                       
                        res.json(workshops);
                    }
                })
            }
        })
    }

    getParticipations = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        Participation.find({'username':username}, (err, part)=>{
            if(err)console.log(err);
            else{
                res.json(part);
            }
        })
    }

    existParticipation = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let name = req.body.name;
        let date = req.body.date;

        Participation.findOne({'username':username,'name':name, 'date':date}, (err, par)=>{
            if(err){console.log(err);}
            else{
                if(par == null){
                    res.json({'message':'false'});
                }else{
                    res.json({'message':'true'});
                }
                
            }
        })
    }

    getAllLikes = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        Likes.find({'username':username}, (err, likes)=>{
            if(err)console.log(err);
            else{
                res.json(likes);
            }
        })
    }

    deleteLike = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let name = req.body.name;

        Likes.deleteOne({'username':username, 'name':name}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    deleteParticipations = (req: express.Request, res: express.Response)=>{
        let username = req.body.name;
        let date = req.body.date;

        Likes.deleteMany({'name':username, 'date':date}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getAllComments = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        Comments.find({'username':username}, (err, comments)=>{
            if(err)console.log(err);
            else{
                res.json(comments);
            }
        })
    }

    deleteComment = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;

        Comments.deleteOne({'_id':id}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    editComment = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let txt = req.body.txt;

        Comments.updateOne({'_id':id}, {$set: {'txt': txt}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getChats = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        Chats.find({'username':username}, (err, chats)=>{
            if(err)console.log(err);
            else{
                res.json(chats);
            }
        })
    }

    getOrgChats = (req: express.Request, res: express.Response)=>{
        let orgusername = req.body.orgusername;

        Chats.find({'orgusername':orgusername}, (err, chats)=>{
            if(err)console.log(err);
            else{
                res.json(chats);
            }
        })
    }

    insertMessage = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let message = req.body.message;
        //let messages = req.body.messages;
        //console.log(id);
        //console.log(messages[0].txt);


        Chats.updateOne({'_id':id}, {$push: {'messages' : { name:message.name, txt:message.txt, time:message.time}}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    
}