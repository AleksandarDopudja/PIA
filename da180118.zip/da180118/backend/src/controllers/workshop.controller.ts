import * as express from 'express';
import Workshop from '../models/workshop'

export class WorkshopController{

    getWorkshops = (req: express.Request, res: express.Response)=>{

        Workshop.find({}, (err, workshops)=>{
            if(err) console.log(err);
            else {
                
                res.json(workshops);
            }
        })
    }

    insertWorkshop = (req: express.Request, res: express.Response)=>{
        let workshop = new Workshop({
            mainphoto: req.body.mainphoto,
            name: req.body.name,
            date: req.body.date,
            place: req.body.place,
            shortinfo: req.body.shortinfo,
            info: req.body.info,
            galery: req.body.galery,
            org: req.body.org,
            capacity: req.body.capacity,
            status: req.body.status
        })

        Workshop.insertMany(workshop);
        res.status(200).json({'message':'workshop added'})
    }

    getMyWorkshops = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        Workshop.find({'org':username}, (err, workshops)=>{
            if(err) console.log(err);
            else {
                
                res.json(workshops);
            }
        })
    }

    setStatusWorkshop = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let status = req.body.status;

        Workshop.updateOne({'_id':id}, {$set: {'status': status}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    deleteWorkshop = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;

        Workshop.deleteOne({'_id':id}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }
    
}