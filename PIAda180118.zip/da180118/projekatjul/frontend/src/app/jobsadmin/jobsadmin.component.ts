import { Component, OnInit } from '@angular/core';
import { Job } from '../models/job';
import { JobService } from '../services/job.service';
import { ClientService } from '../services/client.service';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-jobsadmin',
  templateUrl: './jobsadmin.component.html',
  styleUrls: ['./jobsadmin.component.css']
})
export class JobsadminComponent implements OnInit {

  constructor(private service: JobService, private clientService: ClientService, private router: Router) { }

  jobs: Job[] = [];
  active: Job[] = [];
  currlogin: User;

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getAllJobs().subscribe((jobs: Job[])=>{
      this.jobs = jobs;

      for(var j of this.jobs){
         if(j.status=="aktivan"){
          //this.active.push(j);
        }
        this.active.push(j);
      }
    })
  }

  requestDetails(j){
    sessionStorage.setItem('currjob',JSON.stringify(j));
    this.router.navigate(['/jobdetails']);
  }

}
