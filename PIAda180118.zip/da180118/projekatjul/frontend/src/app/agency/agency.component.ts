import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agency',
  templateUrl: './agency.component.html',
  styleUrls: ['./agency.component.css']
})
export class AgencyComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  loginuser: User;

  @Input() agency: User;

  goDetails(){
    sessionStorage.setItem('curragency', JSON.stringify(this.agency));
    this.router.navigate(['../agencydetails']);
  }
}
