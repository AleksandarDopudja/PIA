import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Raiting } from '../models/raiting';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agencydetails',
  templateUrl: './agencydetails.component.html',
  styleUrls: ['./agencydetails.component.css']
})
export class AgencydetailsComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  loginuser: User;

  agency: User;

  commclients: User[] = [];

  clientsusernames: string[] = [];

  raitings: Raiting[] = []

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.agency = JSON.parse(sessionStorage.getItem('curragency'));

    this.service.getRaitings(this.agency.username).subscribe((rainings: Raiting[])=>{
      this.raitings = rainings;
      this.clientsusernames = this.raitings.map(rating => rating.usernameClient);


      this.service.getUsers(this.clientsusernames).subscribe((users: User[]) => {
        this.commclients = users;
        
        this.matchUsersToRatings();
      });
    });

  }

  matchUsersToRatings(): void {
    for (let i = 0; i < this.raitings.length; i++) {
      for (let j = 0; j < this.commclients.length; j++) {
        if (this.raitings[i].usernameClient == this.commclients[j].username) {
          this.raitings[i].user = this.commclients[j];
        }
      }
    }
  }

  request(){
    this.router.navigate(['/jobrequest']);
  }

  accept(){
    this.service.setStatusUser(this.agency.username, 1).subscribe((rainings: Raiting[])=>{ 
      this.router.navigate(['/regrequests']);
    })
  }

  dismiss(){
    this.service.setStatusUser(this.agency.username, 4).subscribe((rainings: Raiting[])=>{ 
      this.router.navigate(['/regrequests']);
    })
  }

  deleteUser(){
    this.service.deleteUser(this.agency.username).subscribe((rainings: Raiting[])=>{ 
      this.router.navigate(['/adminpage']);
    })
  }

  editUser(){
    sessionStorage.setItem('curredit',JSON.stringify(this.agency));
    this.router.navigate(['/edituser']);
  }

  hasRaitings(){
    return this.raitings.length!=0;
  }

}
