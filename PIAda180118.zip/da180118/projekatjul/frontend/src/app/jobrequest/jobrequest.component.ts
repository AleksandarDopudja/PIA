import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { clientObject } from '../models/object';
import { ClientService } from '../services/client.service';
import { Router } from '@angular/router';
import { JobService } from '../services/job.service';

@Component({
  selector: 'app-jobrequest',
  templateUrl: './jobrequest.component.html',
  styleUrls: ['./jobrequest.component.css']
})
export class JobrequestComponent implements OnInit {

  constructor(private service: ClientService, private router: Router, private jobService: JobService) { }

  loginuser: User;

  objects: clientObject[] = [];

  obj: clientObject = null

  agency: User;

  selectedDateFrom: string = "";
  selectedDateTo: string = "";


  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
    this.agency = JSON.parse(sessionStorage.getItem('curragency'));

    this.service.getObjects(this.loginuser.username).subscribe((objects: clientObject[])=>{
      this.objects = objects;
    });


  }

  sendrequest(){
    //alert(this.obj.street);
    this.jobService.addJobRequest(this.loginuser.username, this.agency.username, this.selectedDateFrom, this.selectedDateTo, this.obj._id).subscribe( response =>{
      //alert("Zahtev uspesno poslat!");
      this.router.navigate(['/clientpage']);
    });
    
  }

}
