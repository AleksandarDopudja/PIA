import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { RegistrationpageComponent } from './registrationpage/registrationpage.component';
import { GuestpageComponent } from './guestpage/guestpage.component';
import { AgencydetailsComponent } from './agencydetails/agencydetails.component';
import { ClientpageComponent } from './clientpage/clientpage.component';
import { ClientprofileComponent } from './clientprofile/clientprofile.component';
import { ClientobjectsComponent } from './clientobjects/clientobjects.component';
import { AddobjectComponent } from './addobject/addobject.component';
import { JobrequestComponent } from './jobrequest/jobrequest.component';
import { JobspageComponent } from './jobspage/jobspage.component';
import { JobdetailsComponent } from './jobdetails/jobdetails.component';
import { AgencypageComponent } from './agencypage/agencypage.component';
import { AgencyprofileComponent } from './agencyprofile/agencyprofile.component';
import { JobsagencyComponent } from './jobsagency/jobsagency.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { RegrequestsComponent } from './regrequests/regrequests.component';
import { JobsadminComponent } from './jobsadmin/jobsadmin.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { EdituserComponent } from './edituser/edituser.component';

const routes: Routes = [
  {path: '', component: WelcomepageComponent},
  {path: 'login', component: LoginpageComponent},
  {path: 'registration', component: RegistrationpageComponent},
  {path: 'guestpage', component: GuestpageComponent},
  {path: 'agencydetails', component: AgencydetailsComponent},
  {path: 'clientpage', component: ClientpageComponent},
  {path: 'clientprofile', component: ClientprofileComponent},
  {path: 'clientobjects', component: ClientobjectsComponent},
  {path: 'addobject', component: AddobjectComponent},
  {path: 'jobrequest', component: JobrequestComponent},
  {path: 'jobspage', component: JobspageComponent},
  {path: 'jobdetails', component: JobdetailsComponent},
  {path: 'agencypage', component: AgencypageComponent},
  {path: 'agencyprofile', component: AgencyprofileComponent},
  {path: 'loginadmin', component: LoginadminComponent},
  {path: 'adminpage', component: AdminpageComponent},
  {path: 'regrequests', component: RegrequestsComponent},
  {path: 'jobsadmin', component: JobsadminComponent},
  {path: 'changepassword', component: ChangepasswordComponent},
  {path: 'edituser', component: EdituserComponent}
  //{path: 'jobagency', component: JobsagencyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
