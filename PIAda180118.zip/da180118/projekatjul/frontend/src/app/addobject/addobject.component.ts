import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { User } from '../models/user';
import { HttpClient } from '@angular/common/http';
import { clientObject } from '../models/object';
import { ClientService } from '../services/client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addobject',
  templateUrl: './addobject.component.html',
  styleUrls: ['./addobject.component.css']
})


export class AddobjectComponent implements OnInit {

  constructor(private http: HttpClient, private service: ClientService, private renderer: Renderer2, private router: Router) { }

  loginuser: User;
  selectedFile: File;

  radio: number = 0

  type: string = "";
  country: string = "";
  city: string = "";
  street: string = "";
  space: number = 0;
  cnt: number = 0;

  doors: string = "";
  walls: string = "";

  message: string = "";

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  obj: clientObject;

  onUpload(): void {
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const fileContent = e.target.result;
        const jsonData = JSON.parse(fileContent);
        console.log(jsonData);
        //alert("ok");
        // Use the loaded JSON data as needed
        this.obj = jsonData;
        //console.log(this.obj.username);
      };
      reader.readAsText(this.selectedFile);
    }
  }

  add(){
    if(this.obj==null) {
      
      this.message="Nije unet fajl!"
      return;
    }
    if(this.radio==2){
      this.service.addObject(this.obj.username, this.obj.country, this.obj.city, this.obj.street, this.obj.type, this.obj.space, this.obj.num, this.obj.walls, this.obj.doors).subscribe((msg)=>{
        this.message="Objekat je unet uspesno!"
      })
    }else if(this.radio==1){

      if(this.cnt==3){
        this.walls = "20,20,120,100,140,70,100,50,20,120,200,100"; //podrazumevani
        this.doors = "140,180,140,80,40,80";
      }
      else if(this.cnt==2){
        this.walls = "140,70,100,50,20,120,200,100"; //podrazumevani
        this.doors = "140,180,140,80";
      }
      else{
        this.walls = "20,120,200,100"; //podrazumevani
        this.doors = "140,180";
      }

      this.service.addObject(this.loginuser.username, this.country, this.city, this.street, this.type, this.space, this.cnt, this.walls, this.doors).subscribe(resp=>{
        this.message = "objekat uspesno dodat!";
      })
    }
  }

}
