import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guestpage',
  templateUrl: './guestpage.component.html',
  styleUrls: ['./guestpage.component.css']
})
export class GuestpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
