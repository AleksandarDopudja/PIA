import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegrequestsComponent } from './regrequests.component';

describe('RegrequestsComponent', () => {
  let component: RegrequestsComponent;
  let fixture: ComponentFixture<RegrequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegrequestsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegrequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
