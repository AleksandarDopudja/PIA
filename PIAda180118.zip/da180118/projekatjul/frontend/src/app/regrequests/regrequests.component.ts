import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-regrequests',
  templateUrl: './regrequests.component.html',
  styleUrls: ['./regrequests.component.css']
})
export class RegrequestsComponent implements OnInit {

  constructor(private service: UserService) { }

  currlogin: User;
  clients: User[] = [];

  agencies: User[] = [];


  ngOnInit(): void {

    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    if(this.currlogin.type == 1 || this.currlogin.type == 0 || this.currlogin.type == 3){
    this.service.getUserRequests().subscribe((u: User[])=>{
      
        for(let i=0;i<u.length;i++){
          if(u[i].type==1){
            this.clients.push(u[i]);
          }else{
            this.agencies.push(u[i]);
          }
        }

      
    })
  }
  }

}
