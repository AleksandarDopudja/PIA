import { Component, Input, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  loginuser: User;

  @Input() agency: User;

  goDetails(){
    sessionStorage.setItem('curragency', JSON.stringify(this.agency));
    this.router.navigate(['../agencydetails']);
  }

}
