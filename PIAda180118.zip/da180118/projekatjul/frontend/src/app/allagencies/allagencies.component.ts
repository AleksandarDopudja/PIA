import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-allagencies',
  templateUrl: './allagencies.component.html',
  styleUrls: ['./allagencies.component.css']
})
export class AllagenciesComponent implements OnInit {

  constructor(private service: UserService) { }

  currlogin: User;
  agencies: User[] = [];
  places: string[] = [];
  countries: string[] = [];



  searchname: string = "";
  searchcity: string = "";
  searchcnt: string = "";
  searchaddr: string = "";
  orgagencies: User[] = [];

  sortName: boolean = false;
  sortCnt: boolean = false;
  sortAdr: boolean = false;
  sortCity: boolean = false;

  nr: boolean = false;

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
      if(this.currlogin.type == 1 || this.currlogin.type == 0 || this.currlogin.type == 3){
      this.service.getAllAgencies().subscribe((agencies: User[])=>{
        if(agencies){
          this.agencies = agencies;
          this.orgagencies = agencies;

          

          for(let i =0;i<this.agencies.length;i++){
            if(!this.places.includes(this.agencies[i].city) && this.agencies[i].city!="")this.places.push(this.agencies[i].city);
            if(!this.countries.includes(this.agencies[i].country) && this.agencies[i].country!="")this.countries.push(this.agencies[i].country);
          }
        }
      })
    }else if(this.currlogin.type == 2){
      
      this.service.getAllAgencies().subscribe((agencies:User[])=>{
        this.agencies = agencies;
        this.orgagencies= agencies;

        for(let i =0;i<this.agencies.length;i++){
          if(!this.places.includes(this.agencies[i].city))this.places.push(this.agencies[i].city);
        }
      })
    }
  }

  search(){
      //alert(this.searchcity);
      this.agencies = this.orgagencies;
      if(this.searchcity!="" || this.searchname!="" || this.searchcnt!="" || this.searchaddr!="")this.agencies = this.service.search(this.searchcnt, this.searchcity, this.searchaddr, this.searchname, this.agencies);
    
  }

  sort(){
    //alert(this.sortName+" "+this.sortCnt+" "+this.sortCity+" "+this.sortAdr);
    this.agencies = this.service.sort(this.sortCnt,this.sortCity,this.sortAdr,this.sortName,this.agencies, this.nr);
    //this.searchaddr = "";
    //this.searchname="";
  }


}
