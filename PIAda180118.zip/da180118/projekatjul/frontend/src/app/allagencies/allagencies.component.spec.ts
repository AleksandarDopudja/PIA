import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllagenciesComponent } from './allagencies.component';

describe('AllagenciesComponent', () => {
  let component: AllagenciesComponent;
  let fixture: ComponentFixture<AllagenciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllagenciesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllagenciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
