export class Job{
    usernameClient: string
    usernameAgency: string
    status: string
    roomsFinished: string
    roomsWorking: string
    dateFrom: string
    dateTo: string
    idobj: string
    numOfWorkers: string
    _id: string
}