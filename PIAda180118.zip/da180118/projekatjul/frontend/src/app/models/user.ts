export class User{
    username: string;
    password: string;
    tell: string;
    mail: string;
    foto: string;
    type: number;
    status: number;
    firstname: string; // klijent
    lastname: string;
    agencyname: string; // agencija
    country: string;
    city: string;
    street: string;
    mb: string; //maticni brojfirme, 8 cif
    about: string;
    _id: string;
}