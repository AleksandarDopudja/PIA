export class Offer{
    idjob: string
    price: string
    spec: string
    _id: string
}