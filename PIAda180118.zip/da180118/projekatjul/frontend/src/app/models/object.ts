
export class clientObject{
    username: string
    type: string
    country: string
    city: string
    street: string
    num: number
    space: number
    walls: string
    doors: string
    _id: string
}
