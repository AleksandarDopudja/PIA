import { User } from "./user";

export class Raiting{
    usernameAgency: string;
    usernameClient: string;
    raiting: number;
    comment: string;
    user: User;
    idobj: string;
    _id: string;
}