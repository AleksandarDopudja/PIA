export class Room{
    walls: string;
    colour: string;
}