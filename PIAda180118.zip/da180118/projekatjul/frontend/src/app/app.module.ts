import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { RegistrationpageComponent } from './registrationpage/registrationpage.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GuestpageComponent } from './guestpage/guestpage.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { AllagenciesComponent } from './allagencies/allagencies.component';
import { AgencyComponent } from './agency/agency.component';
import { AgencydetailsComponent } from './agencydetails/agencydetails.component';
import { ClientpageComponent } from './clientpage/clientpage.component';
import { ClientprofileComponent } from './clientprofile/clientprofile.component';
import { ClientobjectsComponent } from './clientobjects/clientobjects.component';
import { AddobjectComponent } from './addobject/addobject.component';
import { JobrequestComponent } from './jobrequest/jobrequest.component';
import { JobspageComponent } from './jobspage/jobspage.component';
import { JobdetailsComponent } from './jobdetails/jobdetails.component';
import { AgencypageComponent } from './agencypage/agencypage.component';
import { AgencyprofileComponent } from './agencyprofile/agencyprofile.component';
import { JobsagencyComponent } from './jobsagency/jobsagency.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AllclientsComponent } from './allclients/allclients.component';
import { ClientComponent } from './client/client.component';
import { RegrequestsComponent } from './regrequests/regrequests.component';
import { JobsadminComponent } from './jobsadmin/jobsadmin.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { EdituserComponent } from './edituser/edituser.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomepageComponent,
    LoginpageComponent,
    RegistrationpageComponent,
    GuestpageComponent,
    NavbarComponent,
    FooterComponent,
    AllagenciesComponent,
    AgencyComponent,
    AgencydetailsComponent,
    ClientpageComponent,
    ClientprofileComponent,
    ClientobjectsComponent,
    AddobjectComponent,
    JobrequestComponent,
    JobspageComponent,
    JobdetailsComponent,
    AgencypageComponent,
    AgencyprofileComponent,
    JobsagencyComponent,
    LoginadminComponent,
    AdminpageComponent,
    AllclientsComponent,
    ClientComponent,
    RegrequestsComponent,
    JobsadminComponent,
    ChangepasswordComponent,
    EdituserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
