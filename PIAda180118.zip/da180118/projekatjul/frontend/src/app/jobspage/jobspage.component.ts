import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { JobService } from '../services/job.service';
import { Job } from '../models/job';
import { Router } from '@angular/router';

@Component({
  selector: 'app-jobspage',
  templateUrl: './jobspage.component.html',
  styleUrls: ['./jobspage.component.css']
})
export class JobspageComponent implements OnInit {

  constructor(private service: JobService, private router: Router) { }

  currlogin: User;
  jobs: Job[] = [];
  filterjobs: Job[] = [];

  filterOption: string = "";

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    //sessionStorage.setItem('currlogin',JSON.stringify(user));

    this.service.getJobs(this.currlogin.username).subscribe((jobs: Job[])=>{
      this.jobs = jobs;
      this.filterjobs = jobs;
    })
  }

  filter(){

    this.filterjobs = this.jobs;
    if (this.filterOption=="option1"){
      this.filterjobs = this.filterjobs.filter(element => {
        return element.status=="zavrsen";
      });
    }else if(this.filterOption=="option2"){
      this.filterjobs = this.filterjobs.filter(element => {
        return element.status=="aktivan";
      });
    }else if(this.filterOption=="option3"){//requests
      this.filterjobs = this.filterjobs.filter(element => {
        return element.status=="zahtev" || element.status=="odbijen"  || element.status=="prihvacen";
      });
    }

  }

  details(j){
    sessionStorage.setItem('currjob',JSON.stringify(j));
    this.router.navigate(['/jobdetails']);
  }

}
