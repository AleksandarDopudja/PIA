import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-registrationpage',
  templateUrl: './registrationpage.component.html',
  styleUrls: ['./registrationpage.component.css']
})
export class RegistrationpageComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  loginuser: User;

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  @ViewChild('Image') imgType:ElementRef;

  firstname: string = '';
  lastname: string = '';
  username: string = '';
  password: string = '';
  password2: string = '';
  mail: string = '';
  tell: string = '';
  agencyname: string = '';
  country: string = '';
  city: string = '';
  street: string = '';
  about: string = '';
  mb: string = '';
  type: number = 0;
  foto: string = '';

  width:number = 0;
  height:number = 0;

  radio: number = -1;
  radio2: boolean = false;

  message: string = '';

  
  url: any; //Angular 11, for stricter type
	msg = "";
	
	selectFile(event: any) {
  
    var name = event.target.files[0].name;
    console.log(name);
    var type = event.target.files[0].type;
    //var size = event.target.files[0].size;
    //var modifiedDate = event.target.files[0].lastModifiedDate;
  
    let format = type.split("/");
    console.log(format[1])
  
    if (format[1] !== 'png' && format[1] !== 'jpg') {
      this.msg = 'Los format!(samo JPG/PNG)';
      return;
    }
  
    var mimeType = event.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.msg = "Samo su podrzane slike!";
      return;
    }
  
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
  
    reader.onload = (_event) => {
      this.msg = "";
      this.url = reader.result;
      //console.log(reader.result);
  
      // Check image dimensions
      const image = new Image();
      image.src = this.url.toString();
      //console.log(image.src);
      image.onload = () => {
        const width = image.width;
        const height = image.height;
  
        if (width < 100 || height < 100) {
          this.msg = "Slika je premala (minimum 100x100px)!";
          return;
        }
  
        if (width > 300 || height > 300) {
          this.msg = "Slika je prevelika (maksimum 300x300px)!";
          return;
        }
  
        //console.log(width);
        //console.log(height);
      };
    };
  }

  register(){

    //let format = Image.value.split(".");
    //let slika = Image.value.split("\\");
    this.foto = this.url.toString();
    this.type = this.radio;

    if(this.username=='' || this.password=='' || this.password2=='' || this.mail==''){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.radio==1 && (this.firstname=='' || this.lastname=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.radio==2 && (this.agencyname==''||this.country==''||this.city==''||this.street=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.password!=this.password2 ){
      this.message = "Neispravna potvrda lozinke!"
      return false;
    }

    //if(this.tell!=""){
      //if(/^\d\d\d-\d\d\d-\d{3,4}$/.test(this.tell) == false) {
        //this.message = 'Unesite telefon u formatu: xxx-xxx-xxx(x)';
        //return false;
      //}
    //}

    if(/\w@\w/.test(this.mail) == false) {
      this.message = 'Unesite validan mejl sa @!';
      return false;
    }

    if(this.password.length < 7) {
      this.message = 'Lozinka mora sadržati bar 7 karaktera!';
      return false;
    }
    if(this.password.length > 12) {
      this.message = 'Lozinka ne sme sadrzati vise od 12 karaktera!';
      return false;
    }
    if(/[a-z]/.test(this.password) == false) {
      this.message = 'Lozinka mora počinjati slovom!';
      return false;
    }
    if(/[A-Z]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
      return false;
    }
    if(/[\d{+}]/.test(this.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 broj!';
      return false;
    }
    if(/[^a-zA-Z\d]/.test(this.password) == false ) {
      this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
      return false;
    }

    //if(this.radio==2 && /^\d+$/.test(this.mb)){
      //this.message = 'Maticni broj firme moze da sadrzi iskljucivo cifre!'
      //return false;
    //}

    if(this.radio==2 && this.mb.length!=8){
      this.message = 'Maticni broj firme mora da sadrzi 8 cifara!'
      return false;
    }

    
    this.service.register(this.firstname, this.lastname, this.username, this.password, this.tell, this.mail, this.foto, this.type, this.agencyname, this.country, this.city, this.street, this.mb, this.about).subscribe((resp)=>{
            
      if(resp['message']=='user added'){
        this.message = "Uspesno ste poslali zahtev za registraciju! Adminstrator ce u najkracem roku obraditi vas zahtev!";
        //this.router.navigate(['']);
        return true;
      }else{
        this.msg = resp['message'];
        return false;
      }
    });

     return false;       
  }   
      
}
