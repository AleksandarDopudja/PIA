import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-allclients',
  templateUrl: './allclients.component.html',
  styleUrls: ['./allclients.component.css']
})
export class AllclientsComponent implements OnInit {

  constructor(private service: UserService) { }

  currlogin: User;
  clients: User[] = [];

  orgclients: User[] = [];


  ngOnInit(): void {

    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
      if(this.currlogin.type == 1 || this.currlogin.type == 0 || this.currlogin.type == 3){
      this.service.getClientUsers().subscribe((clients: User[])=>{
        if(clients){
          this.clients = clients;
          this.orgclients = clients;

        }
      })
    }
  }

}
