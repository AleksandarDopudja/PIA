import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { User } from '../models/user';
import { Job } from '../models/job';
import { JobService } from '../services/job.service';
import { ClientService } from '../services/client.service';
import { clientObject } from '../models/object';
import { Raiting } from '../models/raiting';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Offer } from '../models/offer';
import { Room } from '../models/room';

@Component({
  selector: 'app-jobdetails',
  templateUrl: './jobdetails.component.html',
  styleUrls: ['./jobdetails.component.css']
})
export class JobdetailsComponent implements OnInit {

  constructor(private service: JobService, private clientService: ClientService, private renderer: Renderer2, private userService: UserService, private router: Router) { 
    
  }

  currlogin: User;
  job: Job;
  obj: clientObject;
  r: Raiting;
  off: Offer;
  price: string;
  num: number;
  room: string;
  cl: string;

  rooms: string[] = [];

  selectednum: number;

  raiting: number;
  comm: string;
  

  @ViewChild('container') container;


  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));
    this.job = JSON.parse(sessionStorage.getItem('currjob'));
    
       
    this.clientService.getObject(this.job.idobj).subscribe(
      (obj: clientObject) => {
        this.obj = obj;
        this.userService.getRaiting(this.job.usernameAgency, this.job.usernameClient, this.obj._id).subscribe(
          (r: Raiting) => {
            this.service.getOffer(this.job._id).subscribe(
              (off: Offer) => {

                this.userService.getNumberFreeWorkers(this.job.usernameAgency).subscribe(
                  (res: any) => {
                    this.num = res.cnt;
                    this.r = r;
                    this.off = off;
                    this.drawCanvas(); 

                    this.splitwalls = this.obj.walls.split(',');
                    for(var i = 0;i<this.splitwalls.length/4;i++){
                      var j = i*4;

                      //this.rooms.push("x:"+this.splitwalls[j+0]+", " + "y:"+this.splitwalls[j+1]+", "+"w: "+this.splitwalls[j+2]+", "+"h: "+this.splitwalls[j+3]);
                      this.rooms.push(this.splitwalls[j+0]+","+this.splitwalls[j+1]+","+this.splitwalls[j+2]+","+this.splitwalls[j+3]);
                    }

                    


                  })
                
              }
            );
          }
        );
      }
    );

    
  }

  splitwalls: string[] = [];

  drawCanvas(): void {
    this.removeCanvas();

    let canvas = this.renderer.createElement('canvas');
    canvas.id = 'CursorLayer';
    canvas.width = 300;
    canvas.height = 300;

    let ctx = canvas.getContext('2d');

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#dddddd';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 3;

    this.splitwalls = [];
    this.splitwalls = this.obj.walls.split(',');
    //alert(this.splitwalls.length)
    for(var i = 0;i<this.splitwalls.length/4;i++){
      var j = i*4;
      
      ctx.strokeRect(this.splitwalls[j+0], this.splitwalls[j+1], this.splitwalls[j+2], this.splitwalls[j+3]);
    }

    if(this.job.status=="aktivan" && parseInt(this.job.numOfWorkers)>0){

    this.splitwalls = [];
      this.splitwalls = this.job.roomsFinished.split(',');
      for(var i = 0;i<this.splitwalls.length/4;i++){
        var j = i*4;
      
        ctx.fillStyle = '#61c398';
        ctx.fillRect(parseInt(this.splitwalls[j+0]) + 1, parseInt(this.splitwalls[j+1]) +1, parseInt(this.splitwalls[j+2])-3, parseInt(this.splitwalls[j+3]) - 3);
      }

      this.splitwalls = [];
      this.splitwalls = this.job.roomsWorking.split(',');
      for(var i = 0;i<this.splitwalls.length/4;i++){
        var j = i*4;
      
        ctx.fillStyle = '#ff5b4f';
        ctx.fillRect(parseInt(this.splitwalls[j+0]) + 1, parseInt(this.splitwalls[j+1]) +1, parseInt(this.splitwalls[j+2])-3, parseInt(this.splitwalls[j+3]) - 3);
      }

    }else if(this.job.status=="aktivan" && parseInt(this.job.numOfWorkers)==0){
      this.splitwalls = this.obj.walls.split(',');
      for(var i = 0;i<this.splitwalls.length/4;i++){
        var j = i*4;
      
        ctx.fillStyle = '#FFFF00';
        ctx.fillRect(parseInt(this.splitwalls[j+0]) + 1, parseInt(this.splitwalls[j+1]) +1, parseInt(this.splitwalls[j+2])-3, parseInt(this.splitwalls[j+3]) - 3);
      }
    }

    const base_image = new Image();
    base_image.src = 'assets/door1.png';
    
    base_image.onload = () => {
      
      this.splitwalls = [];
      this.splitwalls = this.obj.doors.split(',');//splitdoors
      for(var i = 0;i<this.splitwalls.length/2;i++){
        var j = i*2;
        ctx.drawImage(base_image,this.splitwalls[j+0], this.splitwalls[j+1]);
      }
      
    };

    this.container.nativeElement.appendChild(canvas);
  }

  removeCanvas(): void {
    const canvasElement = this.container.nativeElement.querySelector('#CursorLayer');
    if (canvasElement) {
      this.renderer.removeChild(this.container.nativeElement, canvasElement);
    }
  }

  updateRaiting(){

    this.userService.updateRaiting(this.r.raiting, this.r.comment, this.r._id).subscribe(resp=>{
      //alert("OK!");
      //this.router.navigate(['/jobspage']);
    })
  }

  acceptOffer(){
    this.service.updateJob(this.job._id, "aktivan").subscribe(resp=>{
      this.router.navigate(['/jobspage']);
    })
  }

  declainOffer(){
    this.service.deleteRequest(this.job._id).subscribe(resp=>{

      this.service.deleteOffer(this.off._id).subscribe(resp=>{

        this.router.navigate(['/jobspage']);
      })
      
    })
  }

  acceptRequest(){
    this.service.addOffer(this.job._id, this.price).subscribe(resp=>{
      this.service.updateJob(this.job._id, "prihvacen").subscribe(resp=>{
        //alert("ok");
        this.router.navigate(['/agencypage']);
      })
    })
  }

  declainRequest(){
    this.service.updateJob(this.job._id, "odbijen").subscribe(resp=>{
      //alert("ok");
      this.router.navigate(['/agencypage']);
    })
  }

  generateNumberArray(start: number, end: number): number[] {
    const numbers: number[] = [];
    for (let i = start; i <= end; i++) {
      numbers.push(i);
    }
    return numbers;
  }

  isNumOfWorkersZero(): boolean {
    const numOfWorkers = parseInt(this.job.numOfWorkers);
    return numOfWorkers == 0;
  }

  workers: string[] = [];

  addWorkers(){
    
    this.service.addWorkersToJob(this.job._id, this.selectednum).subscribe(resp=>{
      this.userService.workersGetWork(this.job.usernameAgency, this.selectednum, this.obj._id).subscribe(resp=>{
        //alert("ok");
        this.router.navigate(['/agencypage']);
      })
    })
  }

  //room && cl
  paint() {
    if (this.cl === "r") {
      if (!this.job.roomsWorking.includes(this.room)) {
        this.job.roomsWorking = this.job.roomsWorking.concat("," + this.room);
        if (this.job.roomsWorking.startsWith(",")) {
          this.job.roomsWorking = this.job.roomsWorking.substring(1);
        }
        this.job.roomsFinished = this.job.roomsFinished.replace(new RegExp(this.room, "g"), "").replace(/,,/g, ",");
        if (this.job.roomsFinished.startsWith(",")) {
          this.job.roomsFinished = this.job.roomsFinished.substring(1);
        }
        console.log(this.job.roomsFinished);
        console.log(this.job.roomsWorking);
      }
    } else if (this.cl === "g") {
      if (!this.job.roomsFinished.includes(this.room)) {
        this.job.roomsFinished = this.job.roomsFinished.concat("," + this.room);
        if (this.job.roomsFinished.startsWith(",")) {
          this.job.roomsFinished = this.job.roomsFinished.substring(1);
        }
        this.job.roomsWorking = this.job.roomsWorking.replace(new RegExp(this.room, "g"), "").replace(/,,/g, ",");
        if (this.job.roomsWorking.startsWith(",")) {
          this.job.roomsWorking = this.job.roomsWorking.substring(1);
        }
        console.log(this.job.roomsFinished);
        console.log(this.job.roomsWorking);
      }
    } else {
      this.job.roomsFinished = this.job.roomsFinished.replace(new RegExp(this.room, "g"), "").replace(/,,/g, ",");
      if (this.job.roomsFinished.startsWith(",")) {
        this.job.roomsFinished = this.job.roomsFinished.substring(1);
      }
      this.job.roomsWorking = this.job.roomsWorking.replace(new RegExp(this.room, "g"), "").replace(/,,/g, ",");
      if (this.job.roomsWorking.startsWith(",")) {
        this.job.roomsWorking = this.job.roomsWorking.substring(1);
      }
      console.log(this.job.roomsFinished);
      console.log(this.job.roomsWorking);
    }

    this.service.updateJobWork(this.job._id, this.job.roomsFinished, this.job.roomsWorking).subscribe(resp=>{
      this.drawCanvas();
    })
  }

  sendRaiting(){
    this.userService.addRaiting(this.job.usernameAgency, this.job.usernameClient, this.raiting, this.comm, this.job.idobj).subscribe(resp=>{
      this.drawCanvas();
    })
  }

  isOver(){
    
    let n = this.job.roomsFinished.split(',');
    //console.log(n.length);
    return (n.length/4)==this.obj.num;
  }

  pay(){
    this.service.updateJob(this.job._id, "zavrsen").subscribe(resp=>{
      this.userService.workersOffTheWork(this.job.usernameAgency, this.job.numOfWorkers, this.obj._id).subscribe(resp=>{
        this.service.addWorkersToJob(this.job._id, 0).subscribe(resp=>{
          this.router.navigate(['/clientpage']);
        })
      })
      
    })
  }

}
