import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientobjectsComponent } from './clientobjects.component';

describe('ClientobjectsComponent', () => {
  let component: ClientobjectsComponent;
  let fixture: ComponentFixture<ClientobjectsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientobjectsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClientobjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
