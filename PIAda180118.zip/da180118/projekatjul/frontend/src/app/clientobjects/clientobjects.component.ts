import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { User } from '../models/user';
import {clientObject} from '../models/object';
import { ClientService } from '../services/client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-clientobjects',
  templateUrl: './clientobjects.component.html',
  styleUrls: ['./clientobjects.component.css']
})
export class ClientobjectsComponent implements OnInit {

  constructor(private service: ClientService, private renderer: Renderer2, private router: Router) { }


  loginuser: User;

  objects: clientObject[] = [];

  ngOnInit(): void {
    

    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getObjects(this.loginuser.username).subscribe((objects: clientObject[])=>{
      this.objects = objects;
    });

  }

  @ViewChild('container') container;

  drawCan(): void {
    // Remove previous canvas element if it exists
    this.removeCanvas();

    let canvas = this.renderer.createElement('canvas');
    canvas.id = 'CursorLayer';
    canvas.width = 300;
    canvas.height = 300;

    let ctx = canvas.getContext('2d');

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#dddddd';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 20, 120, 100);
    ctx.strokeRect(140, 70, 100, 50);
    ctx.strokeRect(20, 120, 200, 100);

    const base_image = new Image();
    base_image.src = 'assets/door1.png';
    //ctx.drawImage(base_image, 140, 180);

    // Rotate the image by 45 degrees
    base_image.onload = () => {
      // Rotate the image by 45 degrees
      ctx.drawImage(base_image, 140, 180);
      ctx.drawImage(base_image, 140, 80);
      ctx.drawImage(base_image, 40, 80);
      //ctx.translate(canvas.width / 2, canvas.height / 2);
      //ctx.rotate((Math.PI / 180) * 90);
      //ctx.drawImage(base_image, -40, -10);
      //ctx.drawImage(base_image, -110, -10);
      //alert(-base_image.width / 2 +" "+ -base_image.height / 2)
    };

    //ctx.fillRect(20, 20, 120, 100); //za bojanje sobe

    //ctx.drawImage(base_image, 140, 180);

    // Reset the rotation
    

    // Append to Parent Container
    this.container.nativeElement.appendChild(canvas);
  }

  showCanvas: boolean = false;

  splitwalls: string[] = [];

  drawCanvas(o): void {
    this.removeCanvas();

    let canvas = this.renderer.createElement('canvas');
    canvas.id = 'CursorLayer';
    canvas.width = 300;
    canvas.height = 300;

    let ctx = canvas.getContext('2d');

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#dddddd';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;

    this.splitwalls = [];
    this.splitwalls = o.walls.split(',');
    //alert(this.splitwalls.length)
    for(var i = 0;i<this.splitwalls.length/4;i++){
      var j = i*4;
      
      ctx.strokeRect(this.splitwalls[j+0], this.splitwalls[j+1], this.splitwalls[j+2], this.splitwalls[j+3]);
    }

    //ctx.strokeRect(20, 20, 120, 100);
    //ctx.strokeRect(140, 70, 100, 50);
    //ctx.strokeRect(20, 120, 200, 100);

    const base_image = new Image();
    base_image.src = 'assets/door1.png';
    
    base_image.onload = () => {
      
      this.splitwalls = [];
      this.splitwalls = o.doors.split(',');//splitdoors
      for(var i = 0;i<this.splitwalls.length/2;i++){
        var j = i*2;
        ctx.drawImage(base_image,this.splitwalls[j+0], this.splitwalls[j+1]);
      }

      //ctx.drawImage(base_image, 140, 180);
      //ctx.drawImage(base_image, 140, 80);
      //ctx.drawImage(base_image, 40, 80);
      
    };

    this.container.nativeElement.appendChild(canvas);
  }

  draw(o): void {
    this.drawCanvas(o);
    this.showCanvas = true;
  }

  removeCanvas(): void {
    const canvasElement = this.container.nativeElement.querySelector('#CursorLayer');
    if (canvasElement) {
      this.renderer.removeChild(this.container.nativeElement, canvasElement);
    }
  }

  addObject(){
    this.router.navigate(['/addobject']);
  }


}
