import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Raiting } from '../models/raiting';

@Component({
  selector: 'app-agencyprofile',
  templateUrl: './agencyprofile.component.html',
  styleUrls: ['./agencyprofile.component.css']
})
export class AgencyprofileComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  loginuser: User;

  agency: User;

  commclients: User[] = [];

  clientsusernames: string[] = [];

  raitings: Raiting[] = []

  ngOnInit(): void {
    this.agency = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getRaitings(this.agency.username).subscribe((rainings: Raiting[])=>{
      this.raitings = rainings;
      this.clientsusernames = this.raitings.map(rating => rating.usernameClient);


      this.service.getUsers(this.clientsusernames).subscribe((users: User[]) => {
        this.commclients = users;
        
        this.matchUsersToRatings();
      });
    });
  }

  matchUsersToRatings(): void {
    for (let i = 0; i < this.raitings.length; i++) {
      for (let j = 0; j < this.commclients.length; j++) {
        if (this.raitings[i].usernameClient == this.commclients[j].username) {
          this.raitings[i].user = this.commclients[j];
        }
      }
    }
  }

  hasRaitings(){
    return this.raitings.length!=0;
  }

}
