import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }

  loginuser: User;
  oldpassword: string;
  newpassword: string;
  newpassword2: string;

  message: string = "";

  ngOnInit(): void {
    this.loginuser = JSON.parse(sessionStorage.getItem('currlogin'));
  }

  change(){
    if(this.loginuser.password!=this.oldpassword){
      this.message = "Stara lozinka nije tacna!"
    }else{
      if(this.newpassword == this.newpassword2){

        if(this.newpassword.length < 7) {
          this.message = 'Lozinka mora sadržati bar 7 karaktera!';
          return false;
        }
        if(this.newpassword.length > 12) {
          this.message = 'Lozinka ne sme sadrzati vise od 12 karaktera!';
          return false;
        }
        if(/[a-z]/.test(this.newpassword) == false) {
          this.message = 'Lozinka mora počinjati slovom!';
          return false;
        }
        if(/[A-Z]/.test(this.newpassword) == false) {
          this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
          return false;
        }
        if(/[\d{+}]/.test(this.newpassword) == false) {
          this.message = 'Lozinka mora sadržati bar 1 broj!';
          return false;
        }
        if(/[^a-zA-Z\d]/.test(this.newpassword) == false ) {
          this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
          return false;
        }

        this.service.changePassword(this.loginuser.username, this.newpassword).subscribe(resp=>{
          sessionStorage.clear();
          this.message="Lozinka uspesno promenjena!";
          this.router.navigate(['/']);
        })
      }else{
        this.message = "Potvrda lozinke neispravna!"
      }
    }

    return false;
  }

}
