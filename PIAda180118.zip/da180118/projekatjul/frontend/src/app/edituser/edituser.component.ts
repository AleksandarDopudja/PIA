import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  constructor(private router: Router, private service: UserService) { }

  editUser: User;

  message: string = "";

  ngOnInit(): void {
    this.editUser = JSON.parse(sessionStorage.getItem('curredit'));
  }

  edit(){

    if(this.editUser.username=='' || this.editUser.password=='' ||  this.editUser.mail==''){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.editUser.type==1 && (this.editUser.firstname=='' || this.editUser.lastname=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    if(this.editUser.type==2 && (this.editUser.agencyname==''||this.editUser.country==''||this.editUser.city==''||this.editUser.street=='')){
      this.message = "Nisu unete sva obavezna polja!"
      return false;
    }

    //if(this.tell!=""){
      //if(/^\d\d\d-\d\d\d-\d{3,4}$/.test(this.tell) == false) {
        //this.message = 'Unesite telefon u formatu: xxx-xxx-xxx(x)';
        //return false;
      //}
    //}

    if(/\w@\w/.test(this.editUser.mail) == false) {
      this.message = 'Unesite validan mejl sa @!';
      return false;
    }

    if(this.editUser.password.length < 7) {
      this.message = 'Lozinka mora sadržati bar 7 karaktera!';
      return false;
    }
    if(this.editUser.password.length > 12) {
      this.message = 'Lozinka ne sme sadrzati vise od 12 karaktera!';
      return false;
    }
    if(/[a-z]/.test(this.editUser.password) == false) {
      this.message = 'Lozinka mora počinjati slovom!';
      return false;
    }
    if(/[A-Z]/.test(this.editUser.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 veliko slovo!';
      return false;
    }
    if(/[\d{+}]/.test(this.editUser.password) == false) {
      this.message = 'Lozinka mora sadržati bar 1 broj!';
      return false;
    }
    if(/[^a-zA-Z\d]/.test(this.editUser.password) == false ) {
      this.message = 'Lozinka mora sadržati bar 1 specijalan karakter!'
      return false;
    }

    if(this.editUser.type==2 && this.editUser.mb.length!=8){
      this.message = 'Maticni broj firme mora da sadrzi 8 cifara!'
      return false;
    }


    this.service.doesUsernameExist(this.editUser.username).subscribe(resp=>{
      if(resp==true){
        this.message="Korisnicko ime vec u upotrebi!";
      }else{
        this.service.updeteUser(this.editUser).subscribe(resp=>{
          sessionStorage.setItem('curragency',JSON.stringify(this.editUser));
          this.router.navigate(['/agencydetails']);
        })
      }
    })
    

    return false;

  }

}
