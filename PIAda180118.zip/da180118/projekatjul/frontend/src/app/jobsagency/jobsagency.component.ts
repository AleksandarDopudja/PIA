import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { Job } from '../models/job';
import { JobService } from '../services/job.service';
import { ClientService } from '../services/client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-jobsagency',
  templateUrl: './jobsagency.component.html',
  styleUrls: ['./jobsagency.component.css']
})
export class JobsagencyComponent implements OnInit {

  constructor(private service: JobService, private clientService: ClientService, private router: Router) { }

  currlogin: User;

  jobs: Job[] = [];
  requests: Job[] = [];
  active: Job[] = [];

  ngOnInit(): void {
    this.currlogin = JSON.parse(sessionStorage.getItem('currlogin'));

    this.service.getJobsAgency(this.currlogin.username).subscribe((jobs: Job[])=>{
      this.jobs = jobs;

      for(var j of this.jobs){
        if(j.status=="zahtev" || j.status=="prihvacen"){
          this.requests.push(j);
        }
        else if(j.status=="aktivan"){
          this.active.push(j);
        }
      }
    })
  }

  requestDetails(j){
    sessionStorage.setItem('currjob',JSON.stringify(j));
    this.router.navigate(['/jobdetails']);
  }

}
