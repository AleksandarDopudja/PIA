import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobsagencyComponent } from './jobsagency.component';

describe('JobsagencyComponent', () => {
  let component: JobsagencyComponent;
  let fixture: ComponentFixture<JobsagencyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobsagencyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobsagencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
