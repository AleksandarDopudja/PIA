import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  getObjects(usernameclient){
    
    const data={
      username: usernameclient,
    }
    

    return this.http.post(`${this.url}/object/getObjects`, data);
  }

  getObject(id){
    
    const data={
      id: id
    }
    

    return this.http.post(`${this.url}/object/getObject`, data);
  }

  addObject(username, country, city, street, type, space, cnt, walls, doors){
    
    const data={
      username: username,
      country: country,
      city: city, 
      street: street, 
      type: type,
      space: space, 
      num: cnt, 
      walls: walls, 
      doors: doors
    }
    

    return this.http.post(`${this.url}/object/addObject`, data);
  }
}
