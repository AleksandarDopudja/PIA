import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  login(username, password){
    
    const data={
      username: username,
      password: password
    }

    return this.http.post(`${this.url}/user/login`, data);
  }

  register(firstname, lastname, username, password, tell, mail, foto, type, agencyname, country, city, street, mb, about){

    const data={
      firstname: firstname,
      lastname: lastname,
      username: username,
      password: password,
      tell: tell,
      mail: mail,
      foto: foto,
      type: type,
      agencyname: agencyname,
      country: country,
      city: city,
      street: street,
      mb: mb,
      about: about
    }

    return this.http.post(`${this.url}/user/register`, data);
  }

  getAllAgencies(){

    return this.http.post(`${this.url}/user/getAgensies`, null);
  }

  search(cnt, city, adr, agname, agencies){

    if(cnt!=""){
      agencies = agencies.filter(ws=>ws.country==cnt);
    }if(city!=""){
      agencies = agencies.filter(ws=>ws.city==city);
    }if(adr!=""){
      agencies = agencies.filter(ws=>ws.street.includes(adr));
    }if(agname!=""){
      agencies = agencies.filter(ws=>ws.agencyname.includes(agname));
    }

    return agencies;
  }

  sort(c,s,a,n,agencies, nr){

      if(nr==false){
      return agencies.sort((a, b) => {
        if(n){
          if (a.agencyname < b.agencyname) {
              return -1;
          }
          if (a.agencyname > b.agencyname) {
              return 1;
          }
        }

        if(c){
          if(a.country < b.country){
              return -1;
          }
          if(a.country > b.country){
              return 1;
          }
        }

        if(s){
          if(a.city < b.city){
              return -1;
          }
          if(a.city > b.city){
              return 1;
          }
        }

        if(a){
          if(a.street < b.street){
              return -1;
          }
          if(a.street > b.street){
              return 1;
          }
        }

      return 0;});
      }else{
        return agencies.sort((a, b) => {
          if(n){
            if (a.agencyname < b.agencyname) {
                return 1;
            }
            if (a.agencyname > b.agencyname) {
                return -1;
            }
          }
  
          if(c){
            if(a.country < b.country){
                return 1;
            }
            if(a.country > b.country){
                return -1;
            }
          }
  
          if(s){
            if(a.city < b.city){
                return 1;
            }
            if(a.city > b.city){
                return -1;
            }
          }
  
          if(a){
            if(a.street < b.street){
                return 1;
            }
            if(a.street > b.street){
                return -1;
            }
          }
  
        return 0;});
      }
      
  }

  getRaitings(usernameAgency){
    const data={
      usernameAgency: usernameAgency,
    }

    return this.http.post(`${this.url}/user/getRaitings`, data);
  }

  getRaiting(usernameAgency, usernameClient, idobj){
    const data={
      usernameClient: usernameClient,
      usernameAgency: usernameAgency,
      idobj: idobj
    }

    return this.http.post(`${this.url}/user/getRaiting`, data);
  }

  updateRaiting( raiting, comment, id){
    const data={
      id: id,
      raiting: raiting,
      comment: comment
    }

    return this.http.post(`${this.url}/user/updateRaiting`, data);
  }

  getUsers(usernames){
  
    const data={
      usernames: usernames
    }

    return this.http.post(`${this.url}/user/getUsers`, data);
  }

  getUser(username){
  
    const data={
      username: username
    }

    return this.http.post(`${this.url}/user/getUser`, data);
  }

  getNumberFreeWorkers(usernameAgency){

    const data={
      usernameAgency: usernameAgency
    }

    return this.http.post(`${this.url}/user/getNumberFreeWorkers`, data);
  }

  workersGetWork(usernameAgency, num, idobj){

    const data={
      usernameAgency: usernameAgency,
      num: num,
      idobj: idobj
    }

    return this.http.post(`${this.url}/user/workersGetWork`, data);

  }

  getClientUsers(){

    return this.http.post(`${this.url}/user/getClientUsers`, null);
  }

  getUserRequests(){
    return this.http.post(`${this.url}/user/getUserRequests`, null);
  }

  setStatusUser(username, status){

    const data={
      username: username,
      status: status
    }

    return this.http.post(`${this.url}/user/setStatusUser`, data);
  }

  deleteUser(username){

    const data={
      username: username,
    }

    return this.http.post(`${this.url}/user/deleteUser`, data);
  }

  changePassword(username, newpassword){

    const data={
      username: username,
      password: newpassword
    }

    return this.http.post(`${this.url}/user/changePassword`, data);
  }

  updeteUser(user:User){
    const data={
      username: user.username,
      password: user.password,
      tell: user.tell,
      mail: user.mail,
      country: user.country,
      city: user.city,
      street: user.street,
      mb: user.mb,
      firstname: user.firstname,
      lastname: user.lastname,
      agencyname: user.agencyname,
      about: user.about
    }
    
    return this.http.post(`${this.url}/user/updeteUser`, data);
  }


  doesUsernameExist(username){
    const data={
      username: username
    }

    return this.http.post(`${this.url}/user/doesUsernameExist`, data);
  }

  addRaiting(usernameAgency, usernameClient, raiting, comment, idobj){
    const data={
      usernameAgency: usernameAgency,
      usernameClient: usernameClient,
      raiting: raiting,
      comment: comment,
      idobj: idobj
    }

    return this.http.post(`${this.url}/user/addRaiting`, data);
  }

  workersOffTheWork(usernameAgency, num, idobj){
    const data={
      usernameAgency: usernameAgency,
      num: num,
      idobj: idobj
    }

    return this.http.post(`${this.url}/user/workersOffTheWork`, data);
  }


}
