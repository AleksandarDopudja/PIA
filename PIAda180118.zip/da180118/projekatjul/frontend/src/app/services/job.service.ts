import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000';

  addJobRequest(usernameClient, usernameAgency, dateFrom, dateTo, id){
    
    const data={
      usernameClient: usernameClient,
      usernameAgency: usernameAgency,
      dateFrom: dateFrom,
      dateTo: dateTo,
      idobj: id
    }
    

    return this.http.post(`${this.url}/job/addJobRequest`, data);
  }

  getRequests(usernameAgency){
    
    const data={
      username: usernameAgency
    }
    
    return this.http.post(`${this.url}/job/getRequests`, data);
  }

  getJobsAgency(usernameClient){
    
    const data={
      username: usernameClient
    }
    
    return this.http.post(`${this.url}/job/getJobsAgency`, data);
  }

  getJobs(usernameClient){
    
    const data={
      username: usernameClient
    }
    
    return this.http.post(`${this.url}/job/getJobs`, data);
  }

  getJob(id){
    
    const data={
      id: id
    }
    
    return this.http.post(`${this.url}/job/getJob`, data);
  }

  updateJob(id, status){
    
    const data={
      id: id,
      status: status
    }
    
    return this.http.post(`${this.url}/job/updateJob`, data);
  }

  updateJobWork(id, roomsFinished, roomsWorking){
    
    const data={
      id: id,
      roomsFinished: roomsFinished,
      roomsWorking: roomsWorking
    }
    
    return this.http.post(`${this.url}/job/updateJobWork`, data);
  }

  addWorkersToJob(id, num){
    const data={
      id: id,
      num: num
    }
    
    return this.http.post(`${this.url}/job/addWorkersToJob`, data);
  }

  deleteRequest(id){
    
    const data={
      id: id
    }
    
    return this.http.post(`${this.url}/job/deleteRequest`, data);
  }

  getOffer(id){
    
    const data={
      id: id
    }
    
    return this.http.post(`${this.url}/job/getOffer`, data);
  }

  deleteOffer(id){
    
    const data={
      id: id
    }
    
    return this.http.post(`${this.url}/job/deleteOffer`, data);
  }

  addOffer(id, price){
    
    const data={
      id: id,
      price: price
    }
    
    return this.http.post(`${this.url}/job/addOffer`, data);
  }

  getAllJobs(){
    return this.http.post(`${this.url}/job/getAllJobs`, null);
  }
}
