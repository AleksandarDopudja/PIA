import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientpage',
  templateUrl: './clientpage.component.html',
  styleUrls: ['./clientpage.component.css']
})
export class ClientpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
