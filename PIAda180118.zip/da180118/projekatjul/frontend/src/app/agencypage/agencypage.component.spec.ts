import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencypageComponent } from './agencypage.component';

describe('AgencypageComponent', () => {
  let component: AgencypageComponent;
  let fixture: ComponentFixture<AgencypageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgencypageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgencypageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
