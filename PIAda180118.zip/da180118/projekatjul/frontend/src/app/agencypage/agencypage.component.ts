import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agencypage',
  templateUrl: './agencypage.component.html',
  styleUrls: ['./agencypage.component.css']
})
export class AgencypageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
