import * as express from 'express';
import User from '../models/user';
import { parse } from 'path';
import { Int32 } from 'mongodb';
import Raiting from '../models/raiting';
import Worker from '../models/worker'
import raiting from '../models/raiting';

export class UserController{

    login = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let password = req.body.password;

        User.findOne({'username':username, 'password':password}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user);
        })
    }

    register = (req: express.Request, res: express.Response) => {
        const username = req.body.username;
        const mail = req.body.mail;
    
        this.doesUserExist(username, (userExists: boolean) => {
            if (userExists) {
                res.status(200).json({ 'message': 'User already exists' });
            } else {
                this.doesMailInUse(mail, (mailInUse: boolean) => {
                    if (mailInUse) {
                        res.status(200).json({ 'message': 'Email is already in use' });
                    } else {
                        let user = new User({
                            username: username,
                            password: req.body.password,
                            tell: req.body.tell,
                            mail: mail,
                            foto: req.body.foto,
                            type: parseInt(req.body.type),
                            status: 0,
                            firstname: req.body.firstname,
                            lastname: req.body.lastname,
                            agencyname: req.body.agencyname,
                            country: req.body.country,
                            city: req.body.city,
                            street: req.body.street,
                            mb: req.body.mb
                        });

                        //console.log("ok");
    
                        User.insertMany(user);
                        res.status(200).json({ 'message': 'User added' });
                    }
                });
            }
        });
    }

    updeteUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let password = req.body.password;
        let tell = req.body.tell;
        let mail = req.body.mail;
        let country = req.body.country;
        let city = req.body.city;
        let street = req.body.street;
        let mb = req.body.mb;
        let firstname = req.body.firstname;
        let lastname= req.body.lastname;
        let agencyname = req.body.agencyname;
        let about = req.body.about;

        User.updateOne({'username':username}, {$set: {'username': username, 'password': password, 'tell':tell, 'mail':mail, 'country':country, 'city':city, 'street':street, 'mb':mb, 'firstname':firstname, 'lastname':lastname, 'agencyname':agencyname, 'about':about}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }
    
    doesUserExist = (username: string, callback: (userExists: boolean) => void) => {
        User.findOne({ 'username': username }, (err, user) => {
            if (err) {
                console.log(err);
                callback(false);
            } else {
                callback(user !== null);
            }
        });
    }
    
    doesMailInUse = (mail: string, callback: (mailInUse: boolean) => void) => {
        User.findOne({ 'mail': mail }, (err, user) => {
            if (err) {
                console.log(err);
                callback(false);
            } else {
                callback(user !== null);
            }
        });
    }

    doesUsernameExist = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        User.findOne({'username':username}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user!=null);
        })
    }


    changePassword = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let newpassword = req.body.password;

        User.updateOne({'username':username}, {$set: {'password': newpassword}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    setStatusUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let status = req.body.status;

        User.updateOne({'username':username}, {$set: {'status': status}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    deleteUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        User.deleteOne({'username':username}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getUserRequests = (req: express.Request, res: express.Response)=>{

        User.find({'status': 0}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getUsers = (req: express.Request, res: express.Response)=>{
        let usernames = req.body.usernames;

        User.find({'username':{$in:usernames}}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getClientUsers = (req: express.Request, res: express.Response)=>{

        User.find({'type': 1 }, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getUser = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;

        User.find({'username': username }, (err, users)=>{
            if(err) console.log(err);
            else res.json(users);
        })
    }

    getAgensies = (req: express.Request, res: express.Response)=>{
        //console.log("ok");
        User.find({'status': 1, 'type':2}, (err, ags)=>{
            if(err) console.log(err);
            else {
                
                res.json(ags);
            }
        })
    }

    getRaitings = (req: express.Request, res: express.Response)=>{
        //console.log("ok");
        Raiting.find({'usernameAgency': req.body.usernameAgency}, (err, ags)=>{
            if(err) console.log(err);
            else {              
                res.json(ags);
            }
        })
    }

    getRaiting = (req: express.Request, res: express.Response)=>{
        //console.log("ok");
        let usernameClient = req.body.usernameClient;
        let usernameAgency = req.body.usernameAgency;
        let idobj = req.body.idobj;

        Raiting.findOne({'usernameAgency': usernameAgency, 'usernameClient': usernameClient, 'idobj': idobj}, (err, ags)=>{
            if(err) console.log(err);
            else {              
                res.json(ags);
            }
        })
    }

    addRaiting = (req: express.Request, res: express.Response) => { 

        let obj = new raiting({
            usernameAgency: req.body.usernameAgency,
            usernameClient: req.body.usernameClient,
            raiting: req.body.raiting,
            comment: req.body.comment,
            idobj: req.body.idobj

        })
    
        raiting.insertMany(obj);
        res.status(200).json({ 'message': 'Obj added' });
                    
    }

    updateRaiting = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let raiting = req.body.raiting;
        let comment = req.body.comment;

        Raiting.updateOne({'_id':id}, {$set: {'raiting': raiting, 'comment':comment}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getNumberFreeWorkers = (req: express.Request, res: express.Response)=>{
        //console.log("ok");
        let usernameAgency = req.body.usernameAgency;

        Worker.countDocuments({'usernameAgency':usernameAgency, 'idobj':'x'}, (err, count) => {
            if (err) {
              console.error('Error counting users:', err);
              return;
            }
            //console.log('Number of users:', count);
            return res.json({'cnt': count});
          });
    }

    workersGetWork = (req: express.Request, res: express.Response)=>{
       
        let usernameAgency = req.body.usernameAgency;
        let num = req.body.num;
        let idobj = req.body.idobj;

        for(let i=0;i<parseInt(num);i++){
            Worker.updateOne({'usernameAgency':usernameAgency, 'idobj':'x'}, {$set: {'idobj': idobj}}, (err)=>{
                if(err)console.log(err);
                else{
                    
                }
            });
        }

        return res.json({'message':'ok'});
    }

    workersOffTheWork = (req: express.Request, res: express.Response)=>{
       
        let usernameAgency = req.body.usernameAgency;
        let num = req.body.num;
        let idobj = req.body.idobj;

        for(let i=0;i<parseInt(num);i++){
            Worker.updateOne({'usernameAgency':usernameAgency, 'idobj':idobj}, {$set: {'idobj': 'x'}}, (err)=>{
                if(err)console.log(err);
                else{
                    
                }
            });
        }

        return res.json({'message':'ok'});
    }


}