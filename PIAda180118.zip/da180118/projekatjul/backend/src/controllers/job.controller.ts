import * as express from 'express';
import Job from '../models/job';
import offer from '../models/offer';

export class JobController{

    addJobRequest = (req: express.Request, res: express.Response) => {  

        let obj = new Job({
            usernameClient: req.body.usernameClient,
            usernameAgency: req.body.usernameAgency,
            status: "zahtev",
            roomsFinished: "",
            roomsWorking: "",
            dateFrom: req.body.dateFrom,
            dateTo: req.body.dateTo,
            idobj: req.body.idobj,
            numOfWorkers: "0"
        })

        //console.log(obj)
    
        Job.insertMany(obj);
        res.status(200).json({ 'message': 'Job request added' });
                    
    }

    deleteRequest = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;

        Job.deleteOne({'_id':id}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getRequests = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        //console.log("ok");
        //console.log(username);

        Job.find({'usernameAgensy':username, 'status':'zahtev'}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    getJobsAgency = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        //console.log("ok");
        //console.log(username);

        Job.find({'usernameAgency':username}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    getJobs = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        //console.log("ok");
        //console.log(username);

        Job.find({'usernameClient':username}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    getAllJobs = (req: express.Request, res: express.Response)=>{

        Job.find({}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    getJob = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        //console.log("ok");
        //console.log(username);

        Job.findOne({'_id':id}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    updateJob = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let status = req.body.status;

        Job.updateOne({'_id':id}, {$set: {'status': status}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    updateJobWork = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let roomsFinished = req.body.roomsFinished;
        let roomsWorking = req.body.roomsWorking;

        Job.updateOne({'_id':id}, {$set: {'roomsFinished': roomsFinished, 'roomsWorking': roomsWorking}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    addWorkersToJob = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        let num = req.body.num;

        Job.updateOne({'_id':id}, {$set: {'numOfWorkers': num}}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    getOffer = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;

        offer.findOne({'idjob':id}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    deleteOffer = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;

        offer.deleteOne({'_id':id}, (err)=>{
            if(err)console.log(err);
            else{
                return res.json({'message':'ok'});
            }
        });
    }

    addOffer = (req: express.Request, res: express.Response) => {  

        let obj = new offer({
            idjob: req.body.id,
            price: req.body.price,
            spec: ""
        })

        //console.log(obj)
    
        offer.insertMany(obj);
        res.status(200).json({ 'message': 'Job request added' });
                    
    }
}