import * as express from 'express';
import clientObject from '../models/object';

export class objectController{

    getObjects = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        //console.log("ok");
        //console.log(username);

        clientObject.find({'username':username}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    getObject = (req: express.Request, res: express.Response)=>{
        let id = req.body.id;
        //console.log("ok");
        //console.log(username);

        clientObject.findOne({'_id':id}, (err, obj)=>{
            if(err) console.log(err);
            else res.json(obj);
        })
    }

    addObject = (req: express.Request, res: express.Response) => { 

        let obj = new clientObject({
            username: req.body.username,
            country: req.body.country,
            city: req.body.city,
            street: req.body.street,
            num: req.body.num,
            space: req.body.space,
            type: req.body.type,
            walls: req.body.walls,
            doors: req.body.doors

        })
    
        clientObject.insertMany(obj);
        res.status(200).json({ 'message': 'Obj added' });
                    
    }
}