import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import userRouter from './routers/user.routs';
import objectRouter from './routers/object.routs';
import jobRouter from './routers/job.routs';

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/projul');
const connection = mongoose.connection;
connection.once('open', ()=>{
    console.log('db connection ok');
})

//app.get('/', (req, res) => res.send('Hello World!'));

const router = express.Router();
router.use('/user', userRouter);
router.use('/object', objectRouter);
router.use('/job', jobRouter);

app.use('/', router);

app.listen(4000, () => console.log(`Express server running on port 4000`));