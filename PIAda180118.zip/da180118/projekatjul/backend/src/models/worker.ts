import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Worker = new Schema({
    usernameAgency: {
        type: String
    },
    firstname: {
        type: String
    },
    lastname: {
        type: String
    },
    tell: {
        type: String
    },
    mail: {
        type: String
    },
    idobj: {
        type: String
    }
})

export default mongoose.model('Worker', Worker, 'worker');