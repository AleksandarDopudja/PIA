import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Offer = new Schema({
    idjob: {
        type: String
    },
    price: {
        type: String
    },
    spec: {
        type: String
    }
})

export default mongoose.model('Offer', Offer, 'offer');