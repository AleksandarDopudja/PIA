import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Job = new Schema({
    usernameClient: {
        type: String
    },
    usernameAgency: {
        type: String
    },
    status: {
        type: String
    },
    roomsFinished: {
        type: String
    },
    roomsWorking: {
        type: String
    },
    dateFrom: {
        type: String
    },
    dateTo: {
        type: String
    },
    idobj: {
        type: String
    },
    numOfWorkers: {
        type: String
    }
})

export default mongoose.model('Job', Job, 'job');
