import mongoose from "mongoose";

const Schema = mongoose.Schema;

let clientObject = new Schema({
    username: {
        type: String
    },
    type: {
        type: String
    },
    country: {
        type: String
    },
    city: {
        type: String
    },
    street: {
        type: String
    },
    num: {
        type: Number
    },
    space: {
        type: Number
    },
    walls: {
        type: String
    },
    doors: {
        type: String
    }
})

export default mongoose.model('clientObject', clientObject, 'object');