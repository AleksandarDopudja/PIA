import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Raiting = new Schema({
    usernameAgency: {
        type: String
    },
    usernameClient: {
        type: String
    },
    raiting: {
        type: String
    },
    comment: {
        type: String
    },
    idobj: {
        type: String
    }
})

export default mongoose.model('Raiting', Raiting, 'raiting');