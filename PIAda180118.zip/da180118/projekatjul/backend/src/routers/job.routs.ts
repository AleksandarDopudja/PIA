import express from 'express';
import { JobController } from '../controllers/job.controller';

const jobRouter = express.Router();

jobRouter.route('/addJobRequest').post(
    (req,res)=>new JobController().addJobRequest(req,res)
);

jobRouter.route('/deleteRequest').post(
    (req,res)=>new JobController().deleteRequest(req,res)
);

jobRouter.route('/getRequests').post(
    (req,res)=>new JobController().getRequests(req,res)
);

jobRouter.route('/getJobsAgency').post(
    (req,res)=>new JobController().getJobsAgency(req,res)
);

jobRouter.route('/getJobs').post(
    (req,res)=>new JobController().getJobs(req,res)
);

jobRouter.route('/getJob').post(
    (req,res)=>new JobController().getJob(req,res)
);

jobRouter.route('/updateJob').post(
    (req,res)=>new JobController().updateJob(req,res)
);

jobRouter.route('/updateJobWork').post(
    (req,res)=>new JobController().updateJobWork(req,res)
);

jobRouter.route('/getAllJobs').post(
    (req,res)=>new JobController().getAllJobs(req,res)
);

jobRouter.route('/addWorkersToJob').post(
    (req,res)=>new JobController().addWorkersToJob(req,res)
);

jobRouter.route('/getOffer').post(
    (req,res)=>new JobController().getOffer(req,res)
);

jobRouter.route('/deleteOffer').post(
    (req,res)=>new JobController().deleteOffer(req,res)
);

jobRouter.route('/addOffer').post(
    (req,res)=>new JobController().addOffer(req,res)
);

export default jobRouter;