import express from 'express';
import { objectController } from '../controllers/object.controller';

const objectRouter = express.Router();

objectRouter.route('/getObjects').post(
    (req,res)=>new objectController().getObjects(req,res)
);

objectRouter.route('/getObject').post(
    (req,res)=>new objectController().getObject(req,res)
);

objectRouter.route('/addObject').post(
    (req,res)=>new objectController().addObject(req,res)
);

export default objectRouter;