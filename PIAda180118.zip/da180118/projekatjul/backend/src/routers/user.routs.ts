import express from 'express';
import { UserController } from '../controllers/user.controller';

const userRouter = express.Router();

userRouter.route('/login').post(
    (req,res)=>new UserController().login(req,res)
);

userRouter.route('/register').post(
    (req,res)=>new UserController().register(req,res)
);

userRouter.route('/getAgensies').post(
    (req,res)=>new UserController().getAgensies(req,res)
);

userRouter.route('/getRaitings').post(
    (req,res)=>new UserController().getRaitings(req,res)
);

userRouter.route('/getRaiting').post(
    (req,res)=>new UserController().getRaiting(req,res)
);

userRouter.route('/updateRaiting').post(
    (req,res)=>new UserController().updateRaiting(req,res)
);

userRouter.route('/getUsers').post(
    (req,res)=>new UserController().getUsers(req,res)
);

userRouter.route('/getClientUsers').post(
    (req,res)=>new UserController().getClientUsers(req,res)
);

userRouter.route('/getUser').post(
    (req,res)=>new UserController().getUser(req,res)
);

userRouter.route('/getNumberFreeWorkers').post(
    (req,res)=>new UserController().getNumberFreeWorkers(req,res)
);

userRouter.route('/workersGetWork').post(
    (req,res)=>new UserController().workersGetWork(req,res)
);

userRouter.route('/getUserRequests').post(
    (req,res)=>new UserController().getUserRequests(req,res)
);

userRouter.route('/setStatusUser').post(
    (req,res)=>new UserController().setStatusUser(req,res)
);

userRouter.route('/deleteUser').post(
    (req,res)=>new UserController().deleteUser(req,res)
);

userRouter.route('/changePassword').post(
    (req,res)=>new UserController().changePassword(req,res)
);

userRouter.route('/updeteUser').post(
    (req,res)=>new UserController().updeteUser(req,res)
);

userRouter.route('/doesUsernameExist').post(
    (req,res)=>new UserController().doesUsernameExist(req,res)
);

userRouter.route('/addRaiting').post(
    (req,res)=>new UserController().addRaiting(req,res)
);

userRouter.route('/workersOffTheWork').post(
    (req,res)=>new UserController().workersOffTheWork(req,res)
);

export default userRouter;